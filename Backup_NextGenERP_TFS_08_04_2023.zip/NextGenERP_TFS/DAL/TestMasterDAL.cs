﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Modal;

namespace DAL
{
   public class TestMasterDAL
    {
    }
}
