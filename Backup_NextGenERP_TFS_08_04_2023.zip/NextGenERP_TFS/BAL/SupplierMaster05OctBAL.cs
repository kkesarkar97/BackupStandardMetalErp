﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAL;

namespace BAL
{
   public class SupplierMaster05OctBAL
    {
       SupplierMasterDAL05OCT
    }
}
