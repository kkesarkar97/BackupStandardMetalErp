﻿namespace NavnathWebsite {
    
    
    public partial class StandardMetalsDataSet {
    }
}
