﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modal
{
    public class SupplierMasterNMODEL
    {
        public int Id { set; get; }
        public string SupplierName { set; get; }
        public string SupplierCode { set; get; }
        public string ContactPerson { set; get; }
        //public string 
    }
}
