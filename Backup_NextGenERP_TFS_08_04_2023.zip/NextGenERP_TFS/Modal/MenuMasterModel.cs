﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modal
{
   public  class MenuMasterModel
    {
       public int MenuId { get; set; }
        public string MenuName { get; set; }
        public bool IsActive { get; set; }
        public string BranchName { get; set; }

    }
}
