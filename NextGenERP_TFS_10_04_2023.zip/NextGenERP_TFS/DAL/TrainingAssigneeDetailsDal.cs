﻿using Modal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;

namespace DAL
{
    public class TrainingAssigneeDetailsDal
    {
        string strCon = @"Data Source=208.91.198.174;Initial Catalog=aaliml4n_erp;Integrated Security=False;uid=aaliml4n_deverp;password=Aalim@123";
        public DataTable GetTraingSubject()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection conn = new SqlConnection(strCon);
                //Initialize();
                SqlCommand cmdUniversal = new SqlCommand();
                SqlDataAdapter daUniversal = new SqlDataAdapter();
                cmdUniversal.CommandText = "Training_GetTrainingSubject";
                cmdUniversal.Connection = conn;
                daUniversal.SelectCommand = cmdUniversal;
                daUniversal.Fill(dt);
                conn.Close();
            }
            catch(Exception ex)
            { }
            return dt;

        }
        public DataTable BindEmpMasters()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection conn = new SqlConnection(strCon);
                //Initialize();
                SqlCommand cmdUniversal = new SqlCommand();
                SqlDataAdapter daUniversal = new SqlDataAdapter();
                //cmdUniversal.CommandText = "BindEmploymasters";
                cmdUniversal.CommandText = "Training_BindEmploymasters";
                cmdUniversal.Connection = conn;
                daUniversal.SelectCommand = cmdUniversal;
                daUniversal.Fill(dt);
                conn.Close();
            }
            catch (Exception ex)
            { }
            return dt;

        }
        public DataTable GetTrainingTopic(TrainingAssigneeDetailsModel model)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection conn = new SqlConnection(strCon);
                //Initialize();
                SqlCommand cmdUniversal = new SqlCommand();
                SqlDataAdapter daUniversal = new SqlDataAdapter();
                conn.Open();
                cmdUniversal.CommandText = "Training_GetPlannedTrainingTopic";
                //cmdUniversal.CommandText = "GetPlannedTrainingTopic";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                //cmdUniversal.Parameters.AddWithValue("@TrainingSubjectId", model.TrainingSubId);
                cmdUniversal.Parameters.AddWithValue("@TrainSubject", model.TrainingSubId);
                cmdUniversal.Connection = conn;
                daUniversal.SelectCommand = cmdUniversal;
                daUniversal.Fill(dt);
                conn.Close();

            }
            catch (Exception ex)
            { }
            return dt;

        }

        public DataTable SearchAssignedData(string TrainingId)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection conn = new SqlConnection(strCon);
                //Initialize();
                SqlCommand cmdUniversal = new SqlCommand();
                SqlDataAdapter daUniversal = new SqlDataAdapter();
                conn.Open();
                cmdUniversal.CommandText = "Training_SearchAssignDtl";
                //cmdUniversal.CommandText = "GetPlannedTrainingTopic";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                //cmdUniversal.Parameters.AddWithValue("@TrainingSubjectId", model.TrainingSubId);
                cmdUniversal.Parameters.AddWithValue("@TrainingID", TrainingId);
                cmdUniversal.Connection = conn;
                daUniversal.SelectCommand = cmdUniversal;
                daUniversal.Fill(dt);
                conn.Close();

            }
            catch (Exception ex)
            { }
            return dt;



        }
        public DataTable GetTrainingId(TrainingAssigneeDetailsModel model)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection conn = new SqlConnection(strCon);
                //Initialize();
                SqlCommand cmdUniversal = new SqlCommand();
                SqlDataAdapter daUniversal = new SqlDataAdapter();

                cmdUniversal.CommandText = "Training_GetPlannedTrainingID";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                cmdUniversal.Parameters.AddWithValue("@TrainingMatrixID", model.TrainingMatrixId);
                cmdUniversal.Connection = conn;
                daUniversal.SelectCommand = cmdUniversal;
                daUniversal.Fill(dt);
                conn.Close();

            }
            catch (Exception ex)
            { }
            return dt;

        }

        public DataTable GetRecByTrainingId(TrainingAssigneeDetailsModel model)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection conn = new SqlConnection(strCon);
                //Initialize();
                SqlCommand cmdUniversal = new SqlCommand();
                SqlDataAdapter daUniversal = new SqlDataAdapter();
                //cmdUniversal.CommandText = "GetPlannedRecoed";
                cmdUniversal.CommandText = "Training_GetPlannedRecord";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                cmdUniversal.Parameters.AddWithValue("@TrainingID", model.TrainingID);
                cmdUniversal.Connection = conn;
                daUniversal.SelectCommand = cmdUniversal;
                daUniversal.Fill(dt);
                conn.Close();

            }
            catch (Exception ex)
            { }
            return dt;

        }

        public int SaveAssignedData(DataTable newdt)
        {
            int NoOfrowsAffected = 0;
            try
            {
                SqlConnection conn = new SqlConnection(strCon);
                //Initialize();
                SqlCommand cmdUniversal = new SqlCommand();
                
                cmdUniversal.Connection = conn;
                if (newdt.Rows.Count>0)
                {

                    foreach (DataRow Dr in newdt.Rows)
                    {
                        //cmdUniversal.CommandText = "SaveTrainingAssigneddata";
                        cmdUniversal.CommandText = "Training_SaveTrainingAssigneddata";
                        cmdUniversal.CommandType = CommandType.StoredProcedure;
                        cmdUniversal.Parameters.Clear();
                        cmdUniversal.Parameters.AddWithValue("@TrainingID", Dr["ID1"]);
                        cmdUniversal.Parameters.AddWithValue("@TrainingMatrixId", Convert.ToInt32(Dr["ID8"]));
                        cmdUniversal.Parameters.AddWithValue("@TrainingSubID", Convert.ToInt32(Dr["ID7"]));
                        cmdUniversal.Parameters.AddWithValue("@TrainingDate", Convert.ToDateTime(Dr["ID4"]));
                        cmdUniversal.Parameters.AddWithValue("@EmpCode", Dr["ID5"]);
                       // cmdUniversal.Parameters.AddWithValue("@EmpName", Dr["ID6"]);
                        conn.Open();
                        NoOfrowsAffected = cmdUniversal.ExecuteNonQuery();
                        conn.Close();
                    }
                    //    for (int i=0;i<newdt.Rows.Count;i++)
                    //{
                        
                    //    cmdUniversal.CommandText = "SaveTrainingAssigneddata"; 
                    //    cmdUniversal.CommandType = CommandType.StoredProcedure;
                
                    //    cmdUniversal.Parameters.AddWithValue("@TrainingID", newdt.Rows[i]["ID1"]);
                    //    cmdUniversal.Parameters.AddWithValue("@TrainingMatrixId", Convert.ToInt32(newdt.Rows[i]["ID8"]));
                    //    cmdUniversal.Parameters.AddWithValue("@TrainingSubID", Convert.ToInt32(newdt.Rows[i]["ID7"]));
                    //    cmdUniversal.Parameters.AddWithValue("@TrainingDate", Convert.ToDateTime(newdt.Rows[i]["ID4"]));
                    //    cmdUniversal.Parameters.AddWithValue("@EmpCode", newdt.Rows[i]["ID5"]);
                    //    cmdUniversal.Parameters.AddWithValue("@EmpName", newdt.Rows[i]["ID6"]);
                    //    conn.Open();
                    //    NoOfrowsAffected = cmdUniversal.ExecuteNonQuery();
                    //    conn.Close();
                    //}
                }
                

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return NoOfrowsAffected;
        }

        public int UpdateAssignDtl(DataTable newdt)
        {
            int NoOfrowsAffected = 0;
            try
            {
                SqlConnection conn = new SqlConnection(strCon);
                //Initialize();
                SqlCommand cmdUniversal = new SqlCommand();

                cmdUniversal.Connection = conn;
                if (newdt.Rows.Count > 0)
                {

                    foreach (DataRow Dr in newdt.Rows)
                    {
                        cmdUniversal.CommandText = "Training_UpdateAssignedTraining";
                        cmdUniversal.CommandType = CommandType.StoredProcedure;
                        cmdUniversal.Parameters.Clear();
                        cmdUniversal.Parameters.AddWithValue("@TrainingEmployAssID", Dr["ID10"]);
                        cmdUniversal.Parameters.AddWithValue("@TrainingID", Dr["ID1"]);
                        cmdUniversal.Parameters.AddWithValue("@TrainingMatrixId", Convert.ToInt32(Dr["ID8"]));
                        cmdUniversal.Parameters.AddWithValue("@TrainingSubjectId", Convert.ToInt32(Dr["ID7"]));
                        //cmdUniversal.Parameters.AddWithValue("@TrainingDate", Convert.ToDateTime(Dr["ID4"]));
                        cmdUniversal.Parameters.AddWithValue("@EmpCode", Dr["ID5"]);
                        // cmdUniversal.Parameters.AddWithValue("@EmpName", Dr["ID6"]);
                        conn.Open();
                        NoOfrowsAffected = cmdUniversal.ExecuteNonQuery();
                        conn.Close();
                    }
                    //    for (int i=0;i<newdt.Rows.Count;i++)
                    //{

                    //    cmdUniversal.CommandText = "SaveTrainingAssigneddata"; 
                    //    cmdUniversal.CommandType = CommandType.StoredProcedure;

                    //    cmdUniversal.Parameters.AddWithValue("@TrainingID", newdt.Rows[i]["ID1"]);
                    //    cmdUniversal.Parameters.AddWithValue("@TrainingMatrixId", Convert.ToInt32(newdt.Rows[i]["ID8"]));
                    //    cmdUniversal.Parameters.AddWithValue("@TrainingSubID", Convert.ToInt32(newdt.Rows[i]["ID7"]));
                    //    cmdUniversal.Parameters.AddWithValue("@TrainingDate", Convert.ToDateTime(newdt.Rows[i]["ID4"]));
                    //    cmdUniversal.Parameters.AddWithValue("@EmpCode", newdt.Rows[i]["ID5"]);
                    //    cmdUniversal.Parameters.AddWithValue("@EmpName", newdt.Rows[i]["ID6"]);
                    //    conn.Open();
                    //    NoOfrowsAffected = cmdUniversal.ExecuteNonQuery();
                    //    conn.Close();
                    //}
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return NoOfrowsAffected;
        }

    }
}
