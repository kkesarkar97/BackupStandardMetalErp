﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Modal;

namespace DAL
{
    public class QuotationMasterDAL : ConncetionClass
    {
        QuotationMasterModel model = new QuotationMasterModel();

        /*public List<QuotationDetailsModel> GetAllQuotationDetails()
        {
            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "";
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();

                List<QuotationDetailsModel> lst = new List<QuotationDetailsModel>();
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        lst.Add(new QuotationDetailsModel() {
                            ItemName = dt.Rows[i]["ItemName"].ToString(),
                            ItemCode = dt.Rows[i]["ItemCode"].ToString(),
                            DeliveryLeadDate = Convert.ToDateTime(dt.Rows[i]["DeliveryLeadTime"].ToString()),
                            PackingCost = Convert.ToDecimal(dt.Rows[i]["PackingCost"].ToString()),
                            DevelopmentTool = dt.Rows[i]["DevelopmentTool"].ToString(),
                            Material = dt.Rows[i]["Material"].ToString(),
                            Eccess = dt.Rows[i]["Ecess"].ToString(),
                            ServiceTax = Convert.ToInt32(dt.Rows[i]["ServiceTax"]),
                            Excise = dt.Rows[i]["Excise"].ToString(),
                            SaleTax = Convert.ToInt32(dt.Rows[i]["SaleTax"]),
                        });

                    }
                }
                return lst;
             }
        }

        \
        public List<QuotationMasterModel>GetAllQuotationMasterData()
        {
            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "";
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();

                List<QuotationMasterModel> lst = new List<QuotationMasterModel>();
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    { lst.Add(new QuotationMasterModel() {
                        QuotationId = Convert.ToInt32(dt.Rows[i]["Id"]),
                        WithEnquiry = Convert.ToBoolean(dt.Rows[i]["WithEnquiry"]),
                        EnquiryNumber = dt.Rows[i]["EnquiryNumber"].ToString(),
                        RevisionNumber = dt.Rows[i]["RevisionNumber"].ToString(),
                        QuotationNumber = dt.Rows[i]["QuotationNumber"].ToString(),
                        QuotationDate = Convert.ToDateTime(dt.Rows[i]["QuotationDate"]),
                        IsNewCustomer = Convert.ToBoolean(dt.Rows[i]["IsNewCustomer"]),
                        CustomerName = dt.Rows[i]["CustomerName"].ToString(),
                        CustomerCode = dt.Rows[i]["CustomerCode"].ToString(),
                        Address = dt.Rows[i]["Address"].ToString(),
                        Quantity = Convert.ToInt32(dt.Rows[i]["Quantity"]),
                        Rate = Convert.ToInt32(dt.Rows[i]["Rate"]),
                        SymbolId = Convert.ToInt32(dt.Rows[i]["SymbolId"]),

         



                    });
                }
            }
            return lst;
        }
    }*/

        public DataTable BindAllQuotationDetails(int QuotationId)
        {
            DataTable dt = new DataTable();
            this.Initialize();
            int nRecAffected = 0;
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "GetQuoatationDataById";
                cmdUniversal.Parameters.AddWithValue("@QuotationId", QuotationId);
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();

            }
            return dt;
        }
        public DataTable BindCustomer()
        {
            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindCustomer";
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();
                return dt;
            }

        }

        public DataTable BindCustomerName()
        {
            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "Marketing_BindCustomerName";
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();
                return dt;
            }


        }

        public DataTable BindCustomerCode()
        {
            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "Marketing_BindCustomerCode";
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();
                return dt;
            }


        }

        public DataTable BindUnitDrpDown()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindUnit";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }
        public DataTable BindItemNameDrpDown()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "Marketing_BindItemName";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindItemCodeDrpDown()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "Marketing_BindItemCode";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable Marketing_BindEnquiryMasterNo()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "Marketing_BindEnquiryMasterNo";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindSymbolDrpdown()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindDrpdownSymbol";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindStatusDrpdown()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindStatusMaster";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindFreightMaster()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "FreightMasterType";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindValidityType()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindValidityType";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindPackingType()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindPackingType";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindPaymentDrpdown()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindPaymentTypeMaster";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }

        }

        public DataTable BindMarketingModeOfDrpdown()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "ModeOfTransPort";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindToolMasterCode()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindToolMasterCode";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }
        public DataTable BindToolMasterName()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindToolMasterName";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindDrawingBack()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindDrawingBack";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindDeliveryTerm()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindDeliveryTerm";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindApprovedByEmpCode()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindEmpCodeName";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindApprovedByEmpName()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindEmpCodeName";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindItemMaster()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindItemMaster1";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }
        public static int QuoId = 0;
        
        public int SaveQuotationData(QuotationMasterModel model)
        {
            SqlTransaction trans;
            this.Initialize();
            int NoOfRowsAffected = 0;
            int QuotationId = 0;
            
            using (cnUniversal)
            {
                cnUniversal.Open();
                trans = cnUniversal.BeginTransaction();
                try
                {
                    cmdUniversal = new SqlCommand("InsertIntoQuotationMaster", cnUniversal, trans); //SaveQuotationMaster1
                    cmdUniversal.CommandType = CommandType.StoredProcedure;

                    cmdUniversal.Parameters.AddWithValue("@WithEnquiry", model.WithEnquiry);
                    cmdUniversal.Parameters.AddWithValue("@EnquiryId", model.EnquiryId);
                    cmdUniversal.Parameters.AddWithValue("@RevisionNumber", model.RevisionNumber);
                    cmdUniversal.Parameters.AddWithValue("@QuotationNumber", model.QuotationNumber);
                    cmdUniversal.Parameters.AddWithValue("@QuotationDate", System.DateTime.Now);//model.QuotationDate

                    cmdUniversal.Parameters.AddWithValue("@IsNewCustomer", model.IsNewCustomer);
                    cmdUniversal.Parameters.AddWithValue("@NewCustomerCode", model.NewCustomerCode);
                    cmdUniversal.Parameters.AddWithValue("@NewCustomerName", model.NewCustomerName);
                    cmdUniversal.Parameters.AddWithValue("@Id", model.CustomerId);
                    //cmdUniversal.Parameters.AddWithValue("@CustomerCode",model.CustomerCode);
                    //cmdUniversal.Parameters.AddWithValue("@CustomerName",model.CustomerName);
                    cmdUniversal.Parameters.AddWithValue("@ContactPerson", model.ContactPerson);
                    cmdUniversal.Parameters.AddWithValue("@Address", model.Address);
         //           cmdUniversal.Parameters.AddWithValue("@Quantity", model.Quantity);
           //         cmdUniversal.Parameters.AddWithValue("@Rate", model.Rate);
                    //cmdUniversal.Parameters.AddWithValue("@SymbolId", model.SymbolId);
                    cmdUniversal.Parameters.AddWithValue("@LoginUserId", model.LoginUserId);
                    cmdUniversal.Parameters.AddWithValue("@BranchId", model.BranchId);
                    cmdUniversal.Parameters.AddWithValue("@SystemEntryDate", System.DateTime.Now);// model.SystemEntryDate

                    SqlParameter outParamId = new SqlParameter();
                    outParamId.ParameterName = "@QuotationId";
                    outParamId.SqlDbType = System.Data.SqlDbType.Int;
                    outParamId.Direction = System.Data.ParameterDirection.Output;

                    cmdUniversal.Parameters.Add(outParamId);

                    NoOfRowsAffected = cmdUniversal.ExecuteNonQuery();
                    QuotationId = Convert.ToInt32(outParamId.Value.ToString());

                    trans.Commit();
                    this.Close();
                    return QuotationId;
                }

                catch (Exception ex)
                {
                    trans.Rollback();
                    cnUniversal.Close();
                    Console.WriteLine(ex);
                    return NoOfRowsAffected = 0;
                }
            }
        }

        public int SaveQuotationDetails(QuotationDetailsModel dmodel)
        {
            SqlTransaction trans;
            this.Initialize();
            int NoOfRowsAffected = 0;
            using (cnUniversal)
            {
                cnUniversal.Open();
                trans = cnUniversal.BeginTransaction();
                //dmodel.QuotationId = model.QuotationId;
                try
                {
                    cmdUniversal = new SqlCommand("insertintoquotationfinal1", cnUniversal, trans);
                    cmdUniversal.CommandType = CommandType.StoredProcedure;
                    SqlCommandBuilder.DeriveParameters(cmdUniversal);

                    foreach (var quotationdt in dmodel.AllData)
                    {
                        cmdUniversal.Parameters["@QuotationId"].Value = quotationdt.QuotationId;
                        cmdUniversal.Parameters["@ID"].Value = quotationdt.ID;
                        cmdUniversal.Parameters["@ToolMouldId"].Value = quotationdt.ToolMouldId;
                        cmdUniversal.Parameters["@DeliveryLeadTime"].Value = quotationdt.DeliveryLeadTime;
                        cmdUniversal.Parameters["@PackingCost"].Value = Convert.ToDecimal(quotationdt.PackingCost);
                        cmdUniversal.Parameters["@DevelopmentToolCost"].Value = Convert.ToDecimal(quotationdt.DevelopmentToolCost);
                        cmdUniversal.Parameters["@MouldCost"].Value = Convert.ToDecimal(quotationdt.MouldCost);
                        cmdUniversal.Parameters["@MouldCavity"].Value = quotationdt.MouldCavity;
                        cmdUniversal.Parameters["@OtherCost"].Value = Convert.ToDecimal(quotationdt.OtherCost);
                        cmdUniversal.Parameters["@OtherCostRemark"].Value = quotationdt.OtherCostRemark;
                        cmdUniversal.Parameters["@UnitId"].Value = quotationdt.UnitId;
                        cmdUniversal.Parameters["@Material"].Value = quotationdt.Material;
                        cmdUniversal.Parameters["@Ecess"].Value = quotationdt.Ecess;
                        cmdUniversal.Parameters["@ServiceTax"].Value = quotationdt.ServiceTax;
                        cmdUniversal.Parameters["@Excise"].Value = quotationdt.Excise;
                        cmdUniversal.Parameters["@SaleTax"].Value = quotationdt.SalesTax;
                        cmdUniversal.Parameters["@PaymentTypeId"].Value = quotationdt.PaymentTypeId;
                        cmdUniversal.Parameters["@TransportId"].Value = quotationdt.TransportId;
                        cmdUniversal.Parameters["@FreightId"].Value = quotationdt.FreightId;
                        cmdUniversal.Parameters["@PlanTypeId"].Value = quotationdt.PlanTypeId;
                        cmdUniversal.Parameters["@PackingId"].Value = quotationdt.PackingId;
                        cmdUniversal.Parameters["@StatusId"].Value = quotationdt.StatusId;
                        cmdUniversal.Parameters["@AgainstForm"].Value = quotationdt.AgainstFormNo;
                        cmdUniversal.Parameters["@Remark"].Value = quotationdt.Remark;
                        cmdUniversal.Parameters["@DrawingId"].Value = quotationdt.DrawingId;
                        cmdUniversal.Parameters["@SampleRequired"].Value = quotationdt.SampleRequired;
                        cmdUniversal.Parameters["@DeliveryTermId"].Value = quotationdt.DeliveryTermId;
                        cmdUniversal.Parameters["@DocumentRequired"].Value = quotationdt.DocumentRequired;
                        cmdUniversal.Parameters["@Advance"].Value = quotationdt.Advance;
                        cmdUniversal.Parameters["@PreparedByEmpNameId"].Value = quotationdt.PreparedByEmpNameId;
                        cmdUniversal.Parameters["@ApprovedByEmpNameId"].Value = quotationdt.ApprovedByEmpNameId;
                        cmdUniversal.Parameters["@ReviewedByEmpNameId"].Value = quotationdt.ReviewedByEmpNameId;
                        cmdUniversal.Parameters["@ItemSubject"].Value = quotationdt.ItemSubject;
                        cmdUniversal.Parameters["@ItemTerms"].Value = quotationdt.ItemTerms;
                        cmdUniversal.Parameters["@ToolSubject"].Value = quotationdt.ToolSubject;
                        cmdUniversal.Parameters["@ToolTerms"].Value = quotationdt.ToolTerms;
                        cmdUniversal.Parameters["@QR"].Value = quotationdt.QR;
                        cmdUniversal.Parameters["@SymbolId"].Value = quotationdt.SymbolId;
                        cmdUniversal.Parameters["@UnitName"].Value = quotationdt.UnitName;
                        NoOfRowsAffected = cmdUniversal.ExecuteNonQuery();
                    }
                    trans.Commit();
                    this.Close();
                    return NoOfRowsAffected;
                }

                catch (Exception ex)
                {
                    trans.Rollback();
                    cnUniversal.Close();
                    Console.WriteLine(ex);
                    return NoOfRowsAffected = 0;
                }
            }
        }

        public int GetQuotationDetailId(int QuotationId)
        {
            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "GetQuotataionDetailId";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                cmdUniversal.Parameters.AddWithValue("@QuotationId", QuotationId);
                //cmdUniversal.Parameters.Add("@CustCode", SqlDbType.VarChar).Value = CustCode;
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();

            }

            int QuotationDetailId = Convert.ToInt32(dt.Rows[0]["QuatationDetailId"].ToString());
            return QuotationDetailId;
        }
        public DataTable GetMaxQuotationQuotationNo()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "sp_GetMaxQuotationNumber";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;

            }
        }
        public int UpdateQuotationData1(QuotationMasterModel model, QuotationDetailsModel dmodel)
        {
            SqlTransaction trans;
            this.Initialize();
            int NoOfRowsAffected = 0;
            int i=0;

            using (cnUniversal)
            {
                cnUniversal.Open();
                trans = cnUniversal.BeginTransaction();
                try
                {
                    cmdUniversal = new SqlCommand("UpdateQuotationMasterFinal", cnUniversal, trans); //UpdateQuotationMaster1
                    cmdUniversal.CommandType = CommandType.StoredProcedure;
                    cmdUniversal.Parameters.AddWithValue("@WithEnquiry", model.WithEnquiry);
                    cmdUniversal.Parameters.AddWithValue("@EnquiryId", model.EnquiryId);
                    cmdUniversal.Parameters.AddWithValue("@RevisionNumber", model.RevisionNumber);
                    cmdUniversal.Parameters.AddWithValue("@QuotationNumber", model.QuotationNumber);
                    cmdUniversal.Parameters.AddWithValue("@QuotationDate", model.QuotationDate);//model.QuotationDate
                    cmdUniversal.Parameters.AddWithValue("@IsNewCustomer", model.IsNewCustomer);
                    cmdUniversal.Parameters.AddWithValue("@NewCustomerCode", model.NewCustomerCode);
                    cmdUniversal.Parameters.AddWithValue("@NewCustomerName", model.NewCustomerName);
                    cmdUniversal.Parameters.AddWithValue("@Id", model.CustomerId);
                    cmdUniversal.Parameters.AddWithValue("@ContactPerson", model.ContactPerson);
                    cmdUniversal.Parameters.AddWithValue("@Address", model.Address);
                    //cmdUniversal.Parameters.AddWithValue("@Quantity", model.Quantity);
                    //cmdUniversal.Parameters.AddWithValue("@Rate", model.Rate);
                    //cmdUniversal.Parameters.AddWithValue("@SymbolId", model.SymbolId);
                    cmdUniversal.Parameters.AddWithValue("@LoginUserId", model.LoginUserId);
                    cmdUniversal.Parameters.AddWithValue("@BranchId", model.BranchId);
                    cmdUniversal.Parameters.AddWithValue("@SystemEntryDate", System.DateTime.Now);// model.SystemEntryDate
                    cmdUniversal.Parameters.AddWithValue("@QuotationId", model.QuotationId);
                    NoOfRowsAffected = cmdUniversal.ExecuteNonQuery();
                                      
                    cmdUniversal.CommandText = "[dbo].[insertintoquotationfinal1]";
                    cmdUniversal.CommandType = CommandType.StoredProcedure;
                    SqlCommandBuilder.DeriveParameters(cmdUniversal);
                    
                    foreach (var quotationdt in dmodel.AllData)
                    {
                        cmdUniversal.Parameters["@QuotationId"].Value = quotationdt.QuotationId;
                        cmdUniversal.Parameters["@ID"].Value = quotationdt.ID;
                        cmdUniversal.Parameters["@ToolMouldId"].Value = quotationdt.ToolMouldId;
                        cmdUniversal.Parameters["@DeliveryLeadTime"].Value = quotationdt.DeliveryLeadTime;
                        cmdUniversal.Parameters["@PackingCost"].Value = Convert.ToDecimal(quotationdt.PackingCost);
                        cmdUniversal.Parameters["@DevelopmentToolCost"].Value = Convert.ToDecimal(quotationdt.DevelopmentToolCost);
                        cmdUniversal.Parameters["@MouldCost"].Value = Convert.ToDecimal(quotationdt.MouldCost);
                        cmdUniversal.Parameters["@MouldCavity"].Value = quotationdt.MouldCavity;
                        cmdUniversal.Parameters["@OtherCost"].Value = Convert.ToDecimal(quotationdt.OtherCost);
                        cmdUniversal.Parameters["@OtherCostRemark"].Value = quotationdt.OtherCostRemark;
                        cmdUniversal.Parameters["@UnitId"].Value = quotationdt.UnitId;
                        cmdUniversal.Parameters["@Material"].Value = quotationdt.Material;
                        cmdUniversal.Parameters["@Ecess"].Value = quotationdt.Ecess;
                        cmdUniversal.Parameters["@ServiceTax"].Value = quotationdt.ServiceTax;
                        cmdUniversal.Parameters["@Excise"].Value = quotationdt.Excise;
                        cmdUniversal.Parameters["@SaleTax"].Value = quotationdt.SalesTax;
                        cmdUniversal.Parameters["@PaymentTypeId"].Value = quotationdt.PaymentTypeId;
                        cmdUniversal.Parameters["@TransportId"].Value = quotationdt.TransportId;
                        cmdUniversal.Parameters["@FreightId"].Value = quotationdt.FreightId;
                        cmdUniversal.Parameters["@PlanTypeId"].Value = quotationdt.PlanTypeId;
                        cmdUniversal.Parameters["@PackingId"].Value = quotationdt.PackingId;
                        cmdUniversal.Parameters["@StatusId"].Value = quotationdt.StatusId;
                        cmdUniversal.Parameters["@AgainstForm"].Value = quotationdt.AgainstFormNo;
                        cmdUniversal.Parameters["@Remark"].Value = quotationdt.Remark;
                        cmdUniversal.Parameters["@DrawingId"].Value = quotationdt.DrawingId;
                        cmdUniversal.Parameters["@SampleRequired"].Value = quotationdt.SampleRequired;
                        cmdUniversal.Parameters["@DeliveryTermId"].Value = quotationdt.DeliveryTermId;
                        cmdUniversal.Parameters["@DocumentRequired"].Value = quotationdt.DocumentRequired;
                        cmdUniversal.Parameters["@Advance"].Value = quotationdt.Advance;
                        cmdUniversal.Parameters["@PreparedByEmpNameId"].Value = quotationdt.PreparedByEmpNameId;
                        cmdUniversal.Parameters["@ApprovedByEmpNameId"].Value = quotationdt.ApprovedByEmpNameId;
                        cmdUniversal.Parameters["@ReviewedByEmpNameId"].Value = quotationdt.ReviewedByEmpNameId;
                        cmdUniversal.Parameters["@ItemSubject"].Value = quotationdt.ItemSubject;
                        cmdUniversal.Parameters["@ItemTerms"].Value = quotationdt.ItemTerms;
                        cmdUniversal.Parameters["@ToolSubject"].Value = quotationdt.ToolSubject;
                        cmdUniversal.Parameters["@ToolTerms"].Value = quotationdt.ToolTerms;
                        cmdUniversal.Parameters["@QR"].Value = quotationdt.QR;
                        cmdUniversal.Parameters["@SymbolId"].Value = quotationdt.SymbolId;
                        cmdUniversal.Parameters["@UnitName"].Value = quotationdt.UnitName;
                        i = cmdUniversal.ExecuteNonQuery();
                    }
                    trans.Commit();
                    this.Close();

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }   
                    return NoOfRowsAffected+i;
        }
        
                    
      public int UpdataQuotationData(QuotationMasterModel model, QuotationDetailsModel dmodel, int QuotationId)
        {
            SqlTransaction trans;
            this.Initialize();
            int NoOfRowsAffected = 0;
            int QuotationDetailId = 0;

            using (cnUniversal)
            {
                cnUniversal.Open();
                trans = cnUniversal.BeginTransaction();
                try
                {
                    cmdUniversal = new SqlCommand("UpdateQuotationMasterFinal", cnUniversal, trans); //UpdateQuotationMaster1
                    cmdUniversal.CommandType = CommandType.StoredProcedure;
                    model.QuotationId = QuotationId;
                    cmdUniversal.Parameters.AddWithValue("@WithEnquiry", model.WithEnquiry);
                    cmdUniversal.Parameters.AddWithValue("@EnquiryId", model.EnquiryId);
                    cmdUniversal.Parameters.AddWithValue("@RevisionNumber", model.RevisionNumber);
                    cmdUniversal.Parameters.AddWithValue("@QuotationNumber", model.QuotationNumber);
                    cmdUniversal.Parameters.AddWithValue("@QuotationDate", model.QuotationDate);//model.QuotationDate

                    cmdUniversal.Parameters.AddWithValue("@IsNewCustomer", model.IsNewCustomer);
                    cmdUniversal.Parameters.AddWithValue("@NewCustomerCode", model.NewCustomerCode);
                    cmdUniversal.Parameters.AddWithValue("@NewCustomerName", model.NewCustomerName);
                    cmdUniversal.Parameters.AddWithValue("@Id", model.CustomerId);
                    //cmdUniversal.Parameters.AddWithValue("@CustomerCode",model.CustomerCode);
                    //cmdUniversal.Parameters.AddWithValue("@CustomerName",model.CustomerName);
                    cmdUniversal.Parameters.AddWithValue("@ContactPerson", model.ContactPerson);
                    cmdUniversal.Parameters.AddWithValue("@Address", model.Address);
                    //cmdUniversal.Parameters.AddWithValue("@Quantity", model.Quantity);
                    //cmdUniversal.Parameters.AddWithValue("@Rate", model.Rate);
                    //cmdUniversal.Parameters.AddWithValue("@SymbolId", model.SymbolId);
                    cmdUniversal.Parameters.AddWithValue("@LoginUserId", model.LoginUserId);
                    cmdUniversal.Parameters.AddWithValue("@BranchId", model.BranchId);
                    cmdUniversal.Parameters.AddWithValue("@SystemEntryDate", System.DateTime.Now);// model.SystemEntryDate
                    cmdUniversal.Parameters.AddWithValue("@QuotationId", model.QuotationId);
                    int i=0;

                    NoOfRowsAffected = cmdUniversal.ExecuteNonQuery();


                    trans.Commit();
                    this.Close();

                    if (NoOfRowsAffected > 0)
                    {
                        QuotationDetailId = GetQuotationDetailId(model.QuotationId);
                         i= UpdateQuotationDetailsFinal(QuotationId,dmodel,QuotationDetailId);
                    }
                    if(i > 0) { NoOfRowsAffected =1; }


                    return NoOfRowsAffected;
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    cnUniversal.Close();
                    Console.WriteLine(ex);
                    return NoOfRowsAffected = 0;
                }
            }
        }

        public int GetItemCodeById(int QuotationId)
        {
            int ID= 0;
            try {
               
                this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "sp_GetItemCodeById";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                cmdUniversal.Parameters.AddWithValue("@QuotationId", QuotationId);
                //cmdUniversal.Parameters.Add("@CustCode", SqlDbType.VarChar).Value = CustCode;
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();

            }
            
            if (dt == null)
            { 
                ID = 0;
                    
            }
            else
            {
                ID = Convert.ToInt32(dt.Rows[0]["ID"]);
                    
            }
            }
            catch(Exception ex)
            { ID = 0; }
            return ID;
        }

        public DataTable BindAllDataToGrid(int QuotationId)
        {
            //int ID = GetItemCodeById(QuotationId);
            //DataTable dt = new DataTable();
            this.Initialize();

            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "sp_QuotationDetailsGridData2";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                //cmdUniversal.Parameters.AddWithValue("@QuotationId", QuatationDetailId);
                cmdUniversal.Parameters.AddWithValue("@QuotationId", QuotationId);
                //cmdUniversal.Parameters.Add("@CustCode", SqlDbType.VarChar).Value = CustCode;
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                this.daUniversal.Fill(dt);
                this.Close();
            }

            return dt;
        }

        public DataTable BindQuantGrid(int Id)
        {
            
            this.Initialize();
            
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "sp_BindQuantGrid";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                //cmdUniversal.Parameters.AddWithValue("@QuotationId", QuatationDetailId);
                cmdUniversal.Parameters.AddWithValue("@QuotationId", Id);
                //cmdUniversal.Parameters.Add("@CustCode", SqlDbType.VarChar).Value = CustCode;
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                this.daUniversal.Fill(dt);
                this.Close();
            }
            
            return dt;
        }

        public DataTable GetIdByQuotationIdItemCode(int QuoId,int ID)
        {
            this.Initialize();

            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "sp_GetDetailIdByQuoIdID";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                //cmdUniversal.Parameters.AddWithValue("@QuotationId", QuatationDetailId);
                cmdUniversal.Parameters.AddWithValue("@QuotationId", QuoId);
                cmdUniversal.Parameters.AddWithValue("@ID", ID);
                //cmdUniversal.Parameters.Add("@CustCode", SqlDbType.VarChar).Value = CustCode;
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                this.daUniversal.Fill(dt);
                this.Close();
            }

            return dt;
        }
        public int DeleteQuotationData(int QuotationId,int ItemCode)
        {
            
            DataTable dt = GetIdByQuotationIdItemCode(QuotationId, ItemCode);

            
            SqlTransaction trans;
            this.Initialize();
            int NoOfRowsAffected = 0;
            
            using (cnUniversal)
            {
                int Id = Convert.ToInt32(dt.Rows[0]["QuatationDetailId"].ToString());

                cnUniversal.Open();
                trans = cnUniversal.BeginTransaction();
                try
                {
                    cmdUniversal = new SqlCommand("sp_DeleteDetailsData", cnUniversal, trans); //DeleteQuotationMaster
                    cmdUniversal.CommandType = CommandType.StoredProcedure;

                    cmdUniversal.Parameters.AddWithValue("@Id", Id);

                    NoOfRowsAffected = cmdUniversal.ExecuteNonQuery();
                    trans.Commit();
                    this.Close();
                    return NoOfRowsAffected;

                }
                catch (Exception ex) {

                    trans.Rollback();
                    cnUniversal.Close();
                    Console.WriteLine(ex);
                    return NoOfRowsAffected = 0;
                }
            }
        }
        public int UpdateQuotationDetailsFinal(int QuotationId,QuotationDetailsModel dmodel,int QuotationDetailId)
        {
            SqlTransaction trans;
            this.Initialize();
            int NoOfRowsAffected1 = 0;

            dmodel.QuotationDetailsId= QuotationDetailId;
            dmodel.QuotationId= QuotationId;    
            using (cnUniversal)
            {
               
                cnUniversal.Open();
                trans = cnUniversal.BeginTransaction();

                try
                {
                    cmdUniversal = new SqlCommand("UpdateQuotationDetailFinal", cnUniversal,trans);//SaveQuotationDetails
                    cmdUniversal.CommandType = CommandType.StoredProcedure;
                    

                    cmdUniversal.Parameters.AddWithValue("@QuatationDetailId", dmodel.QuotationDetailsId);
                    cmdUniversal.Parameters.AddWithValue("@ID", dmodel.ID);
                    cmdUniversal.Parameters.AddWithValue("@ToolMouldId", dmodel.ToolMouldId);
                    cmdUniversal.Parameters.AddWithValue("@DeliveryLeadTime", dmodel.DeliveryLeadTime);
                    cmdUniversal.Parameters.AddWithValue("@PackingCost", dmodel.PackingCost);
                    cmdUniversal.Parameters.AddWithValue("@DevelopmentToolCost", dmodel.DevelopmentToolCost);
                    cmdUniversal.Parameters.AddWithValue("@MouldCost", dmodel.MouldCost);
                    cmdUniversal.Parameters.AddWithValue("@MouldCavity", dmodel.MouldCavity);
                    cmdUniversal.Parameters.AddWithValue("@OtherCost", dmodel.OtherCost);
                    cmdUniversal.Parameters.AddWithValue("@OtherCostRemark", dmodel.OtherCostRemark);
                    cmdUniversal.Parameters.AddWithValue("@Material", dmodel.Material);
                    cmdUniversal.Parameters.AddWithValue("@UnitId", dmodel.UnitId);
                    cmdUniversal.Parameters.AddWithValue("@Ecess", dmodel.Ecess);
                    cmdUniversal.Parameters.AddWithValue("@ServiceTax", dmodel.ServiceTax);
                    cmdUniversal.Parameters.AddWithValue("@Excise", dmodel.Excise);
                    cmdUniversal.Parameters.AddWithValue("@SaleTax", dmodel.SalesTax);
                    cmdUniversal.Parameters.AddWithValue("@PaymentTypeId", dmodel.PaymentTypeId);
                    cmdUniversal.Parameters.AddWithValue("@TransportId", dmodel.TransportId);
                    cmdUniversal.Parameters.AddWithValue("@FreightId", dmodel.FreightId);
                    cmdUniversal.Parameters.AddWithValue("@PlanTypeId", dmodel.PlanTypeId);
                    cmdUniversal.Parameters.AddWithValue("@PackingId", dmodel.PackingId);
                    cmdUniversal.Parameters.AddWithValue("@StatusId", dmodel.StatusId);
                    cmdUniversal.Parameters.AddWithValue("@AgainstForm", dmodel.AgainstFormNo);
                    cmdUniversal.Parameters.AddWithValue("@Remark", dmodel.Remark);
                    cmdUniversal.Parameters.AddWithValue("@DrawingId", dmodel.DrawingId);
                    cmdUniversal.Parameters.AddWithValue("@SampleRequired", dmodel.SampleRequired);
                    cmdUniversal.Parameters.AddWithValue("@DeliveryTermId", dmodel.DeliveryTermId);
                    cmdUniversal.Parameters.AddWithValue("@DocumentRequired", dmodel.DocumentRequired);
                    cmdUniversal.Parameters.AddWithValue("@Advance", dmodel.Advance);
                    cmdUniversal.Parameters.AddWithValue("@PreparedByEmpNameId", dmodel.PreparedByEmpNameId);
                    cmdUniversal.Parameters.AddWithValue("@ApprovedByEmpNameId", dmodel.ApprovedByEmpNameId);
                    cmdUniversal.Parameters.AddWithValue("@ReviewedByEmpNameId", dmodel.ReviewedByEmpNameId);

                    cmdUniversal.Parameters.AddWithValue("@ItemSubject", dmodel.ItemSubject);
                    cmdUniversal.Parameters.AddWithValue("@ItemTerms", dmodel.ItemTerms);
                    cmdUniversal.Parameters.AddWithValue("@ToolSubject", dmodel.ToolSubject);
                    cmdUniversal.Parameters.AddWithValue("@ToolTerms", dmodel.ToolTerms);
                    cmdUniversal.Parameters.AddWithValue("@QuotationId", dmodel.QuotationId);

                    NoOfRowsAffected1 = cmdUniversal.ExecuteNonQuery();

                    trans.Commit();
                    this.Close();
                    return NoOfRowsAffected1;

                }

                catch (Exception ex)
                {
                    trans.Rollback();
                    cnUniversal.Close();
                    Console.WriteLine(ex);
                    return NoOfRowsAffected1 = 0;
                }

            }
        }

    
        /*public DataTable DisplayQuantityList()
        {

            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "DisplaQuantityMaster";
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();

                List<QuotationMasterModel> lst = new List<QuotationMasterModel>();
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        lst.Add(new QuotationMasterModel()
                        {
                            Quantity = Convert.ToInt32(dt.Rows[i]["Quantity"]),
                            Rate = Convert.ToInt32(dt.Rows[i]["Rate"]),
                            //SymbolId = (dt.Rows[i]["SymbolId"]),
                        });
                    }
                }
                return lst;
            }

        }*/
        public DataTable BindCustDtls(int Id)
        {
            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "Marketing_BindCustDtls";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                cmdUniversal.Parameters.AddWithValue("@Id", Id);
                //cmdUniversal.Parameters.Add("@CustCode", SqlDbType.VarChar).Value = CustCode;
                this.daUniversal.SelectCommand = cmdUniversal; 
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }
        public DataTable BindItemDtls(int Id)
        {
            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindItemDetails";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                cmdUniversal.Parameters.AddWithValue("@ID", Id);
                //cmdUniversal.Parameters.Add("@CustCode", SqlDbType.VarChar).Value = CustCode;
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }
        public DataTable BindQuotationNumber()
        {
            DataTable dt = new DataTable();
            this.Initialize();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindQuotationMaster";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                this.daUniversal.SelectCommand = cmdUniversal;
                cnUniversal.Open();
                daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }
        public DataTable BindToolDetails(int Id)
        {
            this.Initialize();
            int nRecAffected = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindToolDetails";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                cmdUniversal.Parameters.AddWithValue("@Id", Id);
                //cmdUniversal.Parameters.Add("@CustCode", SqlDbType.VarChar).Value = CustCode;
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                nRecAffected = this.daUniversal.Fill(dt);
                this.Close();
                return dt;
            }
        }

        public DataTable BindEnquiryDetails(int Id)
        {
            this.Initialize();
            int NoOfAffectedRows = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "BindEnquiryDetails";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                cmdUniversal.Parameters.AddWithValue("@Id",Id);
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                NoOfAffectedRows = this.daUniversal.Fill(dt);
                this.Close();
            }
            return dt;
        }
        
        public DataTable BindGridViewAll()
        {
            this.Initialize();
            int NoOfAffectedRows = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "sp_QuotatationDetailsDisplay";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                NoOfAffectedRows = this.daUniversal.Fill(dt);
                this.Close();
            }
            return dt;
        }
        
        public DataTable BindGridByItem(int id)
        {
            this.Initialize();
            int NoOfAffectedRows = 0;
            DataTable dt = new DataTable();
            using (cnUniversal)
            {
                cmdUniversal.CommandText = "sp_QuotataiondetailsByItem";
                cmdUniversal.CommandType = CommandType.StoredProcedure;
                cmdUniversal.Parameters.AddWithValue("@Id", id);
                this.daUniversal.SelectCommand = cmdUniversal;
                this.cnUniversal.Open();
                NoOfAffectedRows = this.daUniversal.Fill(dt);
                this.Close();
            }
            return dt;
        }
    }
}

