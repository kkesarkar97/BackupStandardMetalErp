﻿namespace BAL
{
    internal class dbQuotationDetails
    {
        public void GetMaxQuotationNo()
        { }
    }
}