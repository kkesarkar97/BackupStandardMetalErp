﻿using DAL;
using Modal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace BAL
{
    public class TrainingAssigneeDetailsBal
    {
        TrainingAssigneeDetailsDal dal = new TrainingAssigneeDetailsDal();
        public DataTable GetTraingSubject()
        {
            return dal.GetTraingSubject();
        }

        public DataTable SearchAssignedData(string TrainingId)
        {
            return dal.SearchAssignedData(TrainingId);
        }
        public DataTable GetTrainingTopic(TrainingAssigneeDetailsModel model)
        {
            return dal.GetTrainingTopic(model);
        }
        public int UpdateAssignDtl(DataTable dt)
        {
            return dal.UpdateAssignDtl(dt);
        }
        public DataTable GetTrainingId(TrainingAssigneeDetailsModel model)
        {
            return dal.GetTrainingId(model);
        }
        public DataTable GetRecByTrainingId(TrainingAssigneeDetailsModel model)
        {
            return dal.GetRecByTrainingId(model);
        }
        public DataTable BindEmpMasters()
        {
            return dal.BindEmpMasters();
        }
        public int SaveAssignedData(DataTable newdt)
        {
            return dal.SaveAssignedData(newdt);
        }
    }
}
