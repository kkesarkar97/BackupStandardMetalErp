﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modal
{
    public class TrainingAssigneeDetailsModel
    {
        public int TrainingDetailId { set; get; }
        public int TrainingSubId { get; set; }
        public int TrainingMatrixId { get; set; }
        public int EmpCode { get; set; }
        public int EmpName { get; set; }
        public string TrainingID { get; set; }
    }
}
