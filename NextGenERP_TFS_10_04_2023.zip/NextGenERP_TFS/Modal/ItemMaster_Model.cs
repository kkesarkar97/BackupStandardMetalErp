﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modal
{
    public class ItemMaster_Model
    {
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string Manufacturer { get; set; }
        public string Material { get; set; }
    }
}
