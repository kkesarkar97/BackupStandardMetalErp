use StandardMetalDB;

select * From QuotationMasterFinal where QuotationId =7

Select ID from QuotationDetailFinal1 where QuotationId =7

Select * from QuotationMasterFinal inner join QuotationDetailFinal1 on QuotationMasterFinal.QuotationId=QuotationDetailFinal1.QuotationId where QuotationMasterFinal.QuotationId=7;

Create procedure GetDataOfQMQD
@QuotationId int
as
Begin
Select QuotationNumber,ToolMouldId,DeliveryLeadTime,PackingCost,DevelopmentToolCost,MouldCost,MouldCavity,OtherCost,OtherCostRemark,Material,UnitId,Ecess,ServiceTax,Excise,SaleTax,PaymentTypeId,TransportId,FreightId,PlanTypeId,PackingId,StatusId,AgainstForm,Remark,DrawingId,SampleRequired,DeliveryTermId,DocumentRequired,Advance,ItemSubject,ItemTerms,ToolSubject,ToolTerms from QuotationDetailFinal1 inner join QuotationMasterFinal on QuotationDetailFinal1.QuotationId=QuotationMasterFinal.QuotationId where QuotationDetailFinal1.QuotationId=@QuotationId
End; 