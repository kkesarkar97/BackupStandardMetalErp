﻿using BAL;
using Modal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web.Configuration;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;

namespace NavnathWebsite.Marketing
{


    public partial class QuotationMaster : System.Web.UI.Page
    {
        QuotationMasterBAL bal = new QuotationMasterBAL();
        QuotationMasterModel model = new QuotationMasterModel();
        QuotationDetailsModel dmodel = new QuotationDetailsModel();
        
        DataTable DtToCheck = null;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            //DtToCheck = null;
            txtQuotationDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
            txtDeliveryLeadTime.Text = DateTime.Now.ToString("hh:mm tt");
            if (!IsPostBack)
            {
                CalendarExtender2.StartDate = DateTime.Now;
                ViewState["DataBind"] = new DataTable();
                DtToCheck = null;
                BindCustomerName();
                BindCustomerCode();
                //BindCustomer();
                BindUnitDrpDown();
                BindItemNameDrpDown();
                BindItemCodeDrpDown();
                //BindItemMaster();
                Marketing_BindEnquiryMasterNo();
                BindSymbolDrpdown();
                BindPaymentDrpdown();
                BindMarketingModeOfDrpdown();
                BindToolMasterCode();
                BindToolMasterName();
                BindStatusDrpdown();
                BindFreightMaster();
                BindValidityType();
                BindPackingType();
                BindDrawingBack();
                BindDeliveryTerm();
                BindApprovedByEmpCode();
                BindApprovedByEmpName();
                BindPreparedByEmpCode();
                BindPreparedByEmpName();
                BindReviewedByEmpCode();
                BindReviewedByEmpName();
                BindQuotationNumber();

                //Enquiry Section 
                txtRevisionNo.Visible = true;
                txtQuotationNumber.Visible = true;
                txtQuotationDate.Visible = true;
              //txtQuotationDate.Enabled = false;
                drpWithEnquiry.Visible = false;
                txtQuotationNumber.Enabled = false;
                //Customer Section
                txtCustomerName.Visible = false;
                txtCustomerCode.Visible = false;
                rqCustomerCode.Enabled = false;
                rqCustomerName.Enabled = false;
                txtCustomerCode.Text = string.Empty;
                txtCustomerName.Text = string.Empty;
                drpCustomerName.Visible = true;
                drpCustomerCode.Visible = true;

                //Buttons Enabled
                btnUpdate.Enabled = false;
                //btnDelete.Enabled = false;
                btnPreview.Enabled = false;
            }



        }
        
        public void IsCheckEnquiryDetail()
        {
            bool WithEnquiry = chkWithEnquiry.Checked == true ? true : false;

            if (WithEnquiry == true)
            {
                txtRevisionNo.Visible = true;
                txtQuotationNumber.Visible = true;
                txtQuotationDate.Visible = true;
                drpWithEnquiry.Visible = true;
                txtQuotationNumber.Enabled = false;

            }
            else
            {
                txtRevisionNo.Visible = true;
                txtQuotationNumber.Visible = true;
                txtQuotationDate.Visible = true;
                drpWithEnquiry.Visible = false;
                txtQuotationNumber.Enabled = false;
            }
        }


        public void IScheckCustomerDetail()
        {
            bool NewCustomer = chkNewCustomer.Checked == true ? true : false;
            if (NewCustomer == true)
            {
                txtCustomerName.Visible = true;
                txtCustomerCode.Visible = true;
                drpCustomerName.Visible = false;
                drpCustomerCode.Visible = false;
                cmpdrpDownCustName.Enabled = false;
                cmpdrpDownCustCode.Enabled = false;
                txtAddress.Enabled = true;
                txtAddress.Text = string.Empty;
                txtContactPerson.Enabled = true;
                txtContactPerson.Text = string.Empty;
                drpCustomerCode.SelectedIndex = 0;
                drpCustomerName.SelectedIndex = 0;
            }
            else
            {
                txtCustomerName.Visible = false;
                txtCustomerCode.Visible = false;
                rqCustomerCode.Enabled = false;
                rqCustomerName.Enabled = false;
                txtCustomerCode.Text = string.Empty;
                txtCustomerName.Text = string.Empty;
                drpCustomerName.Visible = true;
                drpCustomerCode.Visible = true;
            }
        }
        public void radomItemCodeName()
        {
            if (rdbtnItemWise.Checked)
            {
                BindItemNameDrpDown();
            }
            else if (rdbtnSetWise.Checked)
            {
                BindItemNameDrpDown();
            }
        }

        public void Marketing_BindEnquiryMasterNo()
        {
            DataTable dt = new DataTable();
            dt = bal.Marketing_BindEnquiryMasterNo();
            drpWithEnquiry.Items.Clear();
            drpWithEnquiry.DataSource = dt;
            drpWithEnquiry.DataTextField = "EnquiryNumber";
            drpWithEnquiry.DataValueField = "EnquiryId";
            drpWithEnquiry.DataBind();
            drpWithEnquiry.Items.Insert(0, "---Select---");
            drpWithEnquiry.SelectedIndex = 0;
        }

        public void BindItemNameDrpDown()
        {
            DataTable dt = new DataTable();
            dt = bal.BindItemNameDrpDown();
            drpItemName.Items.Clear();
            drpItemName.DataSource = dt;
            drpItemName.DataTextField = "ItemName";
            drpItemName.DataValueField = "ID";
            drpItemName.DataBind();
            drpItemName.Items.Insert(0, "---Select---");
            drpItemName.SelectedIndex = 0;

        }

        public void BindItemCodeDrpDown()
        {
            DataTable dt = new DataTable();
            dt = bal.BindItemCodeDrpDown();
            drpItemCode.Items.Clear();
            drpItemCode.DataSource = dt;
            drpItemCode.DataTextField = "ItemCode";
            drpItemCode.DataValueField = "ID";
            drpItemCode.DataBind();
            drpItemCode.Items.Insert(0, "---Select---");
            drpItemCode.SelectedIndex = 0;

        }

        public void BindItemMaster()
        {
            DataTable dt = new DataTable();
            dt = bal.BindItemMaster();
            drpItemName.Items.Clear();
            drpItemName.DataSource = dt;
            drpItemName.DataTextField = "ItemName";
            drpItemName.DataValueField = "ItemCode";
            drpItemName.DataBind();
            drpItemName.Items.Insert(0, "---Select---");
            drpItemName.SelectedIndex = 0;

            drpItemCode.Items.Clear();
            drpItemCode.DataSource = dt;
            drpItemCode.DataTextField = "ItemCode";
            drpItemCode.DataValueField = "ItemCode";
            drpItemCode.DataBind();
            drpItemCode.Items.Insert(0, "---Select---");
            drpItemCode.SelectedIndex = 0;
        }

        public void BindCustomer()
        {
            DataTable dt = new DataTable();
            dt = bal.BindCustomer();
            drpCustomerName.Items.Clear();
            drpCustomerName.DataSource = dt;
            drpCustomerName.DataTextField = "CustName";
            drpCustomerName.DataValueField = "CustCode";
            drpCustomerName.DataBind();
            drpCustomerName.Items.Insert(0, "---Select---");
            drpCustomerName.SelectedIndex = 0;

            drpCustomerCode.Items.Clear();
            drpCustomerCode.DataSource = dt;
            drpCustomerCode.DataTextField = "CustCode";
            drpCustomerCode.DataValueField = "CustCode";
            drpCustomerCode.DataBind();
            drpCustomerCode.Items.Insert(0, "---Select---");
            drpCustomerCode.SelectedIndex = 0;
        }

        public void BindCustomerName()
        {
            //BindCustomerCode();

            DataTable dt = new DataTable();
            dt = bal.BindCustomerName();
            drpCustomerName.Items.Clear();
            drpCustomerName.DataSource = dt;
            drpCustomerName.DataTextField = "CustName";
            drpCustomerName.DataValueField = "Id";
            drpCustomerName.DataBind();
            drpCustomerName.Items.Insert(0, "---Select---");
            drpCustomerName.SelectedIndex = 0;

        }

        public void BindCustomerCode()
        {
            DataTable dt = new DataTable();
            dt = bal.BindCustomerCode();
            drpCustomerCode.Items.Clear();
            drpCustomerCode.DataSource = dt;
            drpCustomerCode.DataTextField = "CustCode";
            drpCustomerCode.DataValueField = "Id";
            drpCustomerCode.DataBind();
            drpCustomerCode.Items.Insert(0, "---Select---");
            drpCustomerCode.SelectedIndex = 0;
        }

        public void BindUnitDrpDown()
        {
            DataTable dt = new DataTable();
            dt = bal.BindUnitDrpDown();
            drpUOM.Items.Clear();
            drpUOM.DataSource = dt;
            drpUOM.DataTextField = "UnitName";
            drpUOM.DataValueField = "UnitId";
            drpUOM.DataBind();
            drpUOM.Items.Insert(0, "---Select---");
            drpUOM.SelectedIndex = 0;

        }

        public void BindSymbolDrpdown()
        {
            DataTable dt = new DataTable();
            dt = bal.BindSymbolDrpdown();
            drpRate.Items.Clear();
            drpRate.DataSource = dt;
            drpRate.DataTextField = "SymbolCharacter";
            drpRate.DataValueField = "SymbolId";
            drpRate.DataBind();
            drpRate.Items.Insert(0, "---Select---");
            drpRate.SelectedIndex = 0;
        }

        public void BindStatusDrpdown()
        {
            DataTable dt = new DataTable();
            dt = bal.BindStatusDrpdown();
            drpStatus.Items.Clear();
            drpStatus.DataSource = dt;
            drpStatus.DataTextField = "Status";
            drpStatus.DataValueField = "StatusId";
            drpStatus.DataBind();
            drpStatus.Items.Insert(0, "---Select---");
            drpStatus.SelectedIndex = 0;
        }

        public void BindPaymentDrpdown()
        {
            DataTable dt = new DataTable();
            dt = bal.BindPaymentDrpdown();
            drpPayment.Items.Clear();
            drpPayment.DataSource = dt;
            drpPayment.DataTextField = "PaymentType";
            drpPayment.DataValueField = "PaymentTypeId";
            drpPayment.DataBind();
            drpPayment.Items.Insert(0, "---Select---");
            drpPayment.SelectedIndex = 0;
        }

        public void BindMarketingModeOfDrpdown()
        {
            DataTable dt = new DataTable();
            dt = bal.BindMarketingModeOfDrpdown();
            drpModeOfDispatch.Items.Clear();
            drpModeOfDispatch.DataSource = dt;
            drpModeOfDispatch.DataTextField = "ModeOfTransport";
            drpModeOfDispatch.DataValueField = "TransportId";
            drpModeOfDispatch.DataBind();
            drpModeOfDispatch.Items.Insert(0, "---Select---");
            drpModeOfDispatch.SelectedIndex = 0;
        }

        public void BindToolMasterCode()
        {
            DataTable dt = new DataTable();
            dt = bal.BindToolMasterCode();
            drpToolCode.Items.Clear();
            drpToolCode.DataSource = dt;
            drpToolCode.DataTextField = "ToolMouldCode";
            drpToolCode.DataValueField = "ToolMouldId";
            drpToolCode.DataBind();
            drpToolCode.Items.Insert(0, "---Select---");
            drpToolCode.SelectedIndex = 0;
        }

        public void BindToolMasterName()
        {
            DataTable dt = new DataTable();
            dt = bal.BindToolMasterName();
            drpToolName.Items.Clear();
            drpToolName.DataSource = dt;
            drpToolName.DataTextField = "ToolmouldName";
            drpToolName.DataValueField = "ToolMouldId";
            drpToolName.DataBind();
            drpToolName.Items.Insert(0, "---Select---");
            drpToolName.SelectedIndex = 0;
        }

        public void BindFreightMaster()
        {
            DataTable dt = new DataTable();
            dt = bal.BindFreightMaster();
            drpFrieght.Items.Clear();
            drpFrieght.DataSource = dt;
            drpFrieght.DataTextField = "FreightType";
            drpFrieght.DataValueField = "FreightId";
            drpFrieght.DataBind();
            drpFrieght.Items.Insert(0, "---Select---");
            drpFrieght.SelectedIndex = 0;
        }

        public void BindValidityType()
        {
            DataTable dt = new DataTable();
            dt = bal.BindValidityType();
            drpValidity.Items.Clear();
            drpValidity.DataSource = dt;
            drpValidity.DataTextField = "PlanType";
            drpValidity.DataValueField = "PlanTypeId";
            drpValidity.DataBind();
            drpValidity.Items.Insert(0, "---Select---");
            drpValidity.SelectedIndex = 0;
        }

        public void BindPackingType()
        {
            DataTable dt = new DataTable();
            dt = bal.BindPackingType();
            drpPacking.Items.Clear();
            drpPacking.DataSource = dt;
            drpPacking.DataTextField = "PackingType";
            drpPacking.DataValueField = "PackingId";
            drpPacking.DataBind();
            drpPacking.Items.Insert(0, "---Select---");
            drpPacking.SelectedIndex = 0;
        }

        public void BindDrawingBack()
        {
            DataTable dt = new DataTable();
            dt = bal.BindDrawingBack();
            drpDrawing.Items.Clear();
            drpDrawing.DataSource = dt;
            drpDrawing.DataTextField = "DrawingRefund";
            drpDrawing.DataValueField = "DrawingId";
            drpDrawing.DataBind();
            drpDrawing.Items.Insert(0, "---Select---");
            drpDrawing.SelectedIndex = 0;
        }

        public void BindDeliveryTerm()
        {
            DataTable dt = new DataTable();
            dt = bal.BindDeliveryTerm();
            drpDeliveryTerm.Items.Clear();
            drpDeliveryTerm.DataSource = dt;
            drpDeliveryTerm.DataTextField = "DeliveryTermType";
            drpDeliveryTerm.DataValueField = "DeliveryTermId";
            drpDeliveryTerm.DataBind();
            drpDeliveryTerm.Items.Insert(0, "---Select---");
            drpDeliveryTerm.SelectedIndex = 0;
        }

        public void BindApprovedByEmpCode()
        {
            DataTable dt = new DataTable();
            dt = bal.BindApprovedByEmpCode();
            drpApprovedByEmpCode.Items.Clear();
            drpApprovedByEmpCode.DataSource = dt;
            drpApprovedByEmpCode.DataTextField = "EmpCode";
            drpApprovedByEmpCode.DataValueField = "ESrNo";
            drpApprovedByEmpCode.DataBind();
            drpApprovedByEmpCode.Items.Insert(0, "---Select---");
            drpApprovedByEmpCode.SelectedIndex = 0;

        }

        public void BindApprovedByEmpName()
        {
            DataTable dt = new DataTable();
            dt = bal.BindApprovedByEmpName();
            drpApprovedByEmpName.Items.Clear();
            drpApprovedByEmpName.DataSource = dt;
            drpApprovedByEmpName.DataTextField = "FristName";
            drpApprovedByEmpName.DataValueField = "ESrNo";
            drpApprovedByEmpName.DataBind();
            drpApprovedByEmpName.Items.Insert(0, "---Select---");
            drpApprovedByEmpName.SelectedIndex = 0;

        }

        public void BindPreparedByEmpCode()
        {
            DataTable dt = new DataTable();
            dt = bal.BindApprovedByEmpCode();
            drpPreparedByEmpCode.Items.Clear();
            drpPreparedByEmpCode.DataSource = dt;
            drpPreparedByEmpCode.DataTextField = "EmpCode";
            drpPreparedByEmpCode.DataValueField = "ESrNo";
            drpPreparedByEmpCode.DataBind();
            drpPreparedByEmpCode.Items.Insert(0, "---Select---");
            drpPreparedByEmpCode.SelectedIndex = 0;
        }

        public void BindPreparedByEmpName()
        {
            DataTable dt = new DataTable();
            dt = bal.BindApprovedByEmpName();
            drpPreparedByEmpName.Items.Clear();
            drpPreparedByEmpName.DataSource = dt;
            drpPreparedByEmpName.DataTextField = "FristName";
            drpPreparedByEmpName.DataValueField = "ESrNo";
            drpPreparedByEmpName.DataBind();
            drpPreparedByEmpName.Items.Insert(0, "---Select---");
            drpPreparedByEmpName.SelectedIndex = 0;
        }

        public void BindReviewedByEmpCode()
        {
            DataTable dt = new DataTable();
            dt = bal.BindApprovedByEmpCode();
            drpReviewedByEmpCode.Items.Clear();
            drpReviewedByEmpCode.DataSource = dt;
            drpReviewedByEmpCode.DataTextField = "EmpCode";
            drpReviewedByEmpCode.DataValueField = "ESrNo";
            drpReviewedByEmpCode.DataBind();
            drpReviewedByEmpCode.Items.Insert(0, "---Select---");
            drpReviewedByEmpCode.SelectedIndex = 0;
        }

        public void BindReviewedByEmpName()
        {
            DataTable dt = new DataTable();
            dt = bal.BindApprovedByEmpName();
            drpReviewedByEmpName.Items.Clear();
            drpReviewedByEmpName.DataSource = dt;
            drpReviewedByEmpName.DataTextField = "FristName";
            drpReviewedByEmpName.DataValueField = "ESrNo";
            drpReviewedByEmpName.DataBind();
            drpReviewedByEmpName.Items.Insert(0, "---Select---");
            drpReviewedByEmpName.SelectedIndex = 0;
        }


        public void SaveQuotationData()
        {
            
            model.WithEnquiry = chkWithEnquiry.Checked == true ? true : false;
            if (model.WithEnquiry)
            {
                model.EnquiryId = Convert.ToInt32(drpWithEnquiry.SelectedValue);
                model.RevisionNumber = txtRevisionNo.Text;
                model.QuotationNumber = txtQuotationNumber.Text;
                model.QuotationDate = Convert.ToDateTime(txtQuotationDate.Text);
            }
            else
            {
                model.EnquiryId = 0;
                model.RevisionNumber = txtRevisionNo.Text;
                model.QuotationNumber = txtQuotationNumber.Text;
                model.QuotationDate = DateTime.Now;

            }


            model.IsNewCustomer = chkNewCustomer.Checked == true ? true : false;
            if (model.IsNewCustomer)
            {
                model.NewCustomerName = txtCustomerName.Text;
                model.NewCustomerCode = txtCustomerCode.Text;
                model.CustomerId = 65;
            }
            else
            {
                model.NewCustomerName = string.Empty;
                model.NewCustomerCode = string.Empty;
                model.CustomerId = Convert.ToInt32(drpCustomerName.SelectedValue);
            }
            //model.SymbolId = Convert.ToInt32(drpRate.SelectedValue);
            model.ContactPerson = txtContactPerson.Text;
            model.Address = txtAddress.Text;
            model.LoginUserId = Convert.ToInt32(Session["UserId"]);
            model.BranchId = Convert.ToInt32(Session["BranchId"]);
            model.SystemEntryDate = System.DateTime.Now;

            int QuoId = bal.SaveQuotationData(model);
            SaveQuotationDetails(QuoId);
        }

        public void SaveQuotationDetails(int QuoId)
        {
            dmodel.QuotationId = QuoId;   
            DataTable dt = (DataTable)ViewState["DataBind"];
            List<QuotationDetailsModel> lst = new List<QuotationDetailsModel>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                QuotationDetailsModel qt = new QuotationDetailsModel();
        
                qt.QuotationId = dmodel.QuotationId;
                qt.ID = Convert.ToInt32(dt.Rows[i]["ID1"].ToString());
                qt.ItemName = dt.Rows[i]["ID2"].ToString();
                qt.ToolMouldId = Convert.ToInt32(dt.Rows[i]["ID3"].ToString());
                qt.ToolMouldName = dt.Rows[i]["ID4"].ToString();
                qt.DeliveryLeadTime = DateTime.Now;
                qt.PackingCost = Convert.ToDecimal(dt.Rows[i]["ID6"].ToString());
                qt.DevelopmentToolCost = Convert.ToDecimal(dt.Rows[i]["ID7"].ToString());
                qt.MouldCost = Convert.ToDecimal(dt.Rows[i]["ID8"].ToString());
                qt.MouldCavity = Convert.ToInt32(dt.Rows[i]["ID9"].ToString());
                qt.OtherCost = Convert.ToDecimal(dt.Rows[i]["ID10"].ToString());
                qt.OtherCostRemark = dt.Rows[i]["ID11"].ToString();
                qt.Material = dt.Rows[i]["ID12"].ToString();
                qt.UnitId = 1;
                qt.UnitName = (dt.Rows[i]["ID13"].ToString());
                /*qt.Ecess = (dt.Rows[i]["ID14"].ToString());
                qt.ServiceTax = Convert.ToDecimal(dt.Rows[i]["ID15"].ToString());
                qt.Excise = dt.Rows[i]["ID16"].ToString();
                qt.SalesTax = Convert.ToDecimal(dt.Rows[i]["ID17"].ToString());
                qt.PaymentTypeId = Convert.ToInt32(dt.Rows[i]["ID18"].ToString());
                qt.TransportId = Convert.ToInt32(dt.Rows[i]["ID19"].ToString());
                qt.FreightId = Convert.ToInt32(dt.Rows[i]["ID20"].ToString());
                qt.StatusId = Convert.ToInt32(dt.Rows[i]["ID21"].ToString());
                qt.AgainstFormNo = dt.Rows[i]["ID22"].ToString();
                qt.Remark = dt.Rows[i]["ID23"].ToString();
                qt.DrawingId = Convert.ToInt32(dt.Rows[i]["ID24"].ToString());
                qt.SampleRequired =dt.Rows[i]["ID25"].ToString();
                qt.DocumentRequired = dt.Rows[i]["ID26"].ToString();
                qt.DeliveryTermId = Convert.ToInt32(dt.Rows[i]["ID27"].ToString());
                qt.Advance = Convert.ToDecimal(dt.Rows[i]["ID28"].ToString());
                qt.PreparedByEmpNameId = Convert.ToInt32(dt.Rows[i]["ID29"].ToString());
                qt.ApprovedByEmpNameId = Convert.ToInt32(dt.Rows[i]["ID30"].ToString());
                qt.ReviewedByEmpNameId = Convert.ToInt32(dt.Rows[i]["ID31"].ToString());
                qt.ItemSubject = dt.Rows[i]["ID32"].ToString();
                qt.ItemTerms = dt.Rows[i]["ID33"].ToString();
                qt.ToolSubject = dt.Rows[i]["ID34"].ToString();
                qt.ToolTerms = dt.Rows[i]["ID35"].ToString();*/
                qt.QR = dt.Rows[i]["ID14"].ToString();
                qt.SymbolId = 1;
                qt.Ecess = txtEcess.Text;
                qt.ServiceTax = Convert.ToDecimal(txtServiceTax.Text);
                qt.Excise = txtExcise.Text;
                qt.SalesTax = Convert.ToDecimal(txtSaleTax.Text);
                qt.PaymentTypeId = Convert.ToInt32(drpPayment.SelectedValue);
                qt.TransportId = Convert.ToInt32(drpModeOfDispatch.SelectedValue);
                qt.FreightId = Convert.ToInt32(drpFrieght.SelectedValue);
                qt.PlanTypeId = Convert.ToInt32(drpValidity.SelectedValue);
                qt.PackingId = Convert.ToInt32(drpPacking.SelectedValue);
                qt.StatusId = Convert.ToInt32(drpStatus.SelectedValue);
                qt.AgainstFormNo = txtAgainstFormNo.Text;
                qt.Remark = txtRemark.Text;
                qt.DrawingId = Convert.ToInt32(drpDrawing.SelectedValue);
                qt.SampleRequired = txtSampleRequired.Text;
                qt.DeliveryTermId = Convert.ToInt32(drpDeliveryTerm.SelectedValue);
                qt.DocumentRequired = txtDocumentRequired.Text;
                qt.Advance = Convert.ToDecimal(txtAdvance.Text);
                qt.PreparedByEmpNameId = Convert.ToInt32(drpPreparedByEmpName.SelectedValue);
                qt.ApprovedByEmpNameId = Convert.ToInt32(drpApprovedByEmpName.SelectedValue);
                qt.ReviewedByEmpNameId = Convert.ToInt32(drpReviewedByEmpName.SelectedValue);

                qt.ItemSubject = txtItemSubject.Text;
                qt.ItemTerms = txtItemTerms.Text;
                qt.ToolSubject = txtToolSubject.Text;
                qt.ToolTerms = txtToolTerms.Text;
                lst.Add(qt);
            }
            dmodel.AllData = lst;


            dmodel.QuotationId = model.QuotationId;

        }

        public void UpdateQuotationData(int QuotationId)
        {
            
            model.WithEnquiry = chkWithEnquiry.Checked == true ? true : false;
            if (model.WithEnquiry)
            {
                model.EnquiryId = Convert.ToInt32(drpWithEnquiry.SelectedValue);
                model.RevisionNumber = txtRevisionNo.Text;
                model.QuotationNumber = txtQuotationNumber.Text;
                model.QuotationDate = Convert.ToDateTime(txtQuotationDate.Text);
            }
            else
            {
                model.EnquiryId = 0;
                model.RevisionNumber = txtRevisionNo.Text;
                model.QuotationNumber = txtQuotationNumber.Text;
                model.QuotationDate = DateTime.Now;

            }


            model.IsNewCustomer = chkNewCustomer.Checked == true ? true : false;
            if (model.IsNewCustomer)
            {
                model.NewCustomerName = txtCustomerName.Text;
                model.NewCustomerCode = txtCustomerCode.Text;
                model.CustomerId = 1;
                rqCustomerCode.Enabled = true;
                rqCustomerName.Enabled = true;

            }
            else
            {
                model.NewCustomerName = string.Empty;
                model.NewCustomerCode = string.Empty;
                model.CustomerId = Convert.ToInt32(drpCustomerName.SelectedValue);
            }
            
            model.ContactPerson = txtContactPerson.Text;
            model.Address = txtAddress.Text;
            model.QuotationId = QuotationId;

            DataTable dt = (DataTable)ViewState["DataBind"];

            List <QuotationDetailsModel> lst = new List<QuotationDetailsModel>();
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                QuotationDetailsModel qt = new QuotationDetailsModel();
            
                qt.QuotationId = model.QuotationId;
                qt.ID = Convert.ToInt32(dt.Rows[i]["ID1"].ToString());
                qt.ItemName = dt.Rows[i]["ID2"].ToString();
                qt.ToolMouldId = Convert.ToInt32(dt.Rows[i]["ID3"].ToString());
                qt.ToolMouldName = dt.Rows[i]["ID4"].ToString();
                qt.DeliveryLeadTime = DateTime.Now;
                qt.PackingCost = Convert.ToDecimal(dt.Rows[i]["ID6"].ToString());
                qt.DevelopmentToolCost = Convert.ToDecimal(dt.Rows[i]["ID7"].ToString());
                qt.MouldCost = Convert.ToDecimal(dt.Rows[i]["ID8"].ToString());
                qt.MouldCavity = Convert.ToInt32(dt.Rows[i]["ID9"].ToString());
                qt.OtherCost = Convert.ToDecimal(dt.Rows[i]["ID10"].ToString());
                qt.OtherCostRemark = dt.Rows[i]["ID11"].ToString();
                qt.Material = dt.Rows[i]["ID12"].ToString();
                qt.UnitId = 1;  // Convert.ToInt32(dt.Rows[i]["ID13"].ToString());
                qt.UnitName = dt.Rows[i]["ID13"].ToString();
                /*qt.Ecess = (dt.Rows[i]["ID14"].ToString());
                qt.ServiceTax = Convert.ToDecimal(dt.Rows[i]["ID15"].ToString());
                qt.Excise = dt.Rows[i]["ID16"].ToString();
                qt.SalesTax = Convert.ToDecimal(dt.Rows[i]["ID17"].ToString());
                qt.PaymentTypeId = Convert.ToInt32(dt.Rows[i]["ID18"].ToString());
                qt.TransportId = Convert.ToInt32(dt.Rows[i]["ID19"].ToString());
                qt.FreightId = Convert.ToInt32(dt.Rows[i]["ID20"].ToString());
                qt.StatusId = Convert.ToInt32(dt.Rows[i]["ID21"].ToString());
                qt.AgainstFormNo = dt.Rows[i]["ID22"].ToString();
                qt.Remark = dt.Rows[i]["ID23"].ToString();
                qt.DrawingId = Convert.ToInt32(dt.Rows[i]["ID24"].ToString());
                qt.SampleRequired =dt.Rows[i]["ID25"].ToString();
                qt.DocumentRequired = dt.Rows[i]["ID26"].ToString();
                qt.DeliveryTermId = Convert.ToInt32(dt.Rows[i]["ID27"].ToString());
                qt.Advance = Convert.ToDecimal(dt.Rows[i]["ID28"].ToString());
                qt.PreparedByEmpNameId = Convert.ToInt32(dt.Rows[i]["ID29"].ToString());
                qt.ApprovedByEmpNameId = Convert.ToInt32(dt.Rows[i]["ID30"].ToString());
                qt.ReviewedByEmpNameId = Convert.ToInt32(dt.Rows[i]["ID31"].ToString());
                qt.ItemSubject = dt.Rows[i]["ID32"].ToString();
                qt.ItemTerms = dt.Rows[i]["ID33"].ToString();
                qt.ToolSubject = dt.Rows[i]["ID34"].ToString();
                qt.ToolTerms = dt.Rows[i]["ID35"].ToString();*/
                qt.QR = dt.Rows[i]["ID14"].ToString();
                qt.SymbolId = 1;
                qt.Ecess = txtEcess.Text;
                qt.ServiceTax = Convert.ToDecimal(txtServiceTax.Text);
                qt.Excise = txtExcise.Text;
                qt.SalesTax = Convert.ToDecimal(txtSaleTax.Text);
                qt.PaymentTypeId = Convert.ToInt32(drpPayment.SelectedValue);
                qt.TransportId = Convert.ToInt32(drpModeOfDispatch.SelectedValue);
                qt.FreightId = Convert.ToInt32(drpFrieght.SelectedValue);
                qt.PlanTypeId = Convert.ToInt32(drpValidity.SelectedValue);
                qt.PackingId = Convert.ToInt32(drpPacking.SelectedValue);
                qt.StatusId = Convert.ToInt32(drpStatus.SelectedValue);
                qt.AgainstFormNo = txtAgainstFormNo.Text;
                qt.Remark = txtRemark.Text;
                qt.DrawingId = Convert.ToInt32(drpDrawing.SelectedValue);
                qt.SampleRequired = txtSampleRequired.Text;
                qt.DeliveryTermId = Convert.ToInt32(drpDeliveryTerm.SelectedValue);
                qt.DocumentRequired = txtDocumentRequired.Text;
                qt.Advance = Convert.ToDecimal(txtAdvance.Text);
                qt.PreparedByEmpNameId = Convert.ToInt32(drpPreparedByEmpName.SelectedValue);
                qt.ApprovedByEmpNameId = Convert.ToInt32(drpApprovedByEmpName.SelectedValue);
                qt.ReviewedByEmpNameId = Convert.ToInt32(drpReviewedByEmpName.SelectedValue);

                qt.ItemSubject = txtItemSubject.Text;
                qt.ItemTerms = txtItemTerms.Text;
                qt.ToolSubject = txtToolSubject.Text;
                qt.ToolTerms = txtToolTerms.Text;
                lst.Add(qt);
            }
            dmodel.AllData = lst;
            
            
            model.LoginUserId = Convert.ToInt32(Session["UserId"]);
            model.BranchId = Convert.ToInt32(Session["BranchId"]);
            model.SystemEntryDate = System.DateTime.Now;
            
        }


        protected void btnSave_Click(object sender, EventArgs e)
        {
            int res = 0;
            try
            {
                int i=BindGridDataDuringSave();
                
                if (i > 0)
                {
                    Label1.Text = "Please Fill Quotation Table ...!!!";
                    Response.Write("<script> alert('Please Fill Quotation Table ...!!!') </Script>");
                }
                else
                {
                    SaveQuotationData();
                    res = bal.SaveQuotationDetails(dmodel);
                }

                rqCustomerCode.Enabled = false;
                rqCustomerName.Enabled = false;

                if (res > 0)
                {
                    Lbl1.Text = "Record Saved Successfully";
                    DataTable dt = bal.GetMaxQuotationQuotationNo();
                    if(dt.Rows.Count>0)
                    {
                        txtQuotationNumber.Text = dt.Rows[0]["QuotationNumber"].ToString();
                    }
                }
                else
                {
                    Lbl1.Text = "Record Not Saved Successfully";
                    Label1.Visible = false;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        public void ResetAllData()
        {
            drpQuotationNo.SelectedIndex = 0;
            drpWithEnquiry.SelectedIndex = 0;
            txtRevisionNo.Text = string.Empty;
            txtQuotationNumber.Text = string.Empty;
            txtQuotationDate.Text = string.Empty;
            drpCustomerCode.SelectedIndex = 0;
            drpCustomerName.SelectedIndex = 0;
            txtCustomerName.Text = string.Empty;
            txtCustomerCode.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtContactPerson.Text = string.Empty;
            drpItemCode.SelectedIndex = 0;
            drpItemName.SelectedIndex = 0;
            drpToolCode.SelectedIndex = 0;
            drpToolName.SelectedIndex = 0;
            txtDeliveryLeadTime.Text = string.Empty;

            txtPackingCost.Text = string.Empty;
            txtDevelopmentToolCost.Text = string.Empty;
            txtMouldCost.Text = string.Empty;
            txtMouldCavity.Text = string.Empty;
            txtOtherCost.Text = string.Empty;
            txtOtherCostRemark.Text = string.Empty;
            txtMaterial.Text = string.Empty;
            drpUOM.SelectedIndex = 0;
            txtQuantity.Text = string.Empty;
            txtRate.Text = string.Empty;
            drpRate.SelectedIndex = 0;
            txtEcess.Text = string.Empty;
            txtServiceTax.Text = string.Empty;
            txtExcise.Text = string.Empty;
            txtServiceTax.Text = string.Empty;
            drpPayment.SelectedIndex = 0;
            drpModeOfDispatch.SelectedIndex = 0;
            drpFrieght.SelectedIndex = 0;
            drpValidity.SelectedIndex = 0;
            drpPacking.SelectedIndex = 0;
            drpStatus.SelectedIndex = 0;
            txtAgainstFormNo.Text = string.Empty;
            txtRemark.Text = string.Empty;
            drpDrawing.SelectedIndex = 0;
            txtSampleRequired.Text = string.Empty;
            drpDeliveryTerm.SelectedIndex = 0;
            txtDocumentRequired.Text = string.Empty;
            txtAdvance.Text = string.Empty;
            drpPreparedByEmpCode.SelectedIndex = 0;
            drpPreparedByEmpName.SelectedIndex = 0;
            drpApprovedByEmpCode.SelectedIndex = 0;
            drpApprovedByEmpName.SelectedIndex = 0;
            drpReviewedByEmpCode.SelectedIndex = 0;
            drpReviewedByEmpName.SelectedIndex = 0;
            txtItemSubject.Text = string.Empty;
            txtItemTerms.Text = string.Empty;
            txtToolSubject.Text = string.Empty;
            txtToolTerms.Text = string.Empty;
            Lbl1.Visible = false;
            Label1.Visible = false;
            chkWithEnquiry.Checked = false;
            chkNewCustomer.Checked = false;

            DtToCheck = (DataTable)ViewState["DataBind"];
            
                DataTable dt1 = CreateTable(15);
                dt1.Rows.Add();
                if (ViewState["DataBind"] == null)
            {
                dt1.Rows.Clear();
                BindAllList(dt1);
            }
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
            //btnDelete.Enabled = false;
            rqCustomerCode.Enabled = false;
            rqCustomerName.Enabled = false;

        }

        private bool CheckDuplicateQuantity()
        {
            bool Duplicate = false;
            DataTable dt = (DataTable)ViewState["DataQuant"];
            if (dt==null)
            {  }
            else
            {
                string quantity = dt.Rows[0]["ID1"].ToString();   
                if(string.Equals(txtQuantity.Text,quantity))
                {
                    
                        Response.Write("<script> alert('Duplicate values are not Allowed ...!!!') </Script>");
                        return true;
                    
                }
            }

            return Duplicate;
        }
        protected void btnAddRate_Click(object sender, EventArgs e)
        {
            try {
                if (!CheckDuplicateQuantity())
                {
                    BindQuantData();
                    ResetQuantData();
                }
                else
                { }
            }
            catch(Exception ex)
            { BindQuantData();
                ResetQuantData();
            }
            
        }

        protected void ResetQuantData()
        {
            txtQuantity.Text = string.Empty;
            txtRate.Text = string.Empty;
            drpRate.SelectedIndex=0;
        }

        protected void BindCustDtls(int id)
        {
            DataTable dt = new DataTable();
            dt = bal.BindCustDtls(id);
            txtAddress.Enabled = true;
            txtContactPerson.Enabled = true;
            if (dt.Rows.Count > 0)
            {
                txtContactPerson.Text = dt.Rows[0]["ContactPerson"].ToString();
                txtAddress.Text = dt.Rows[0]["Address1"].ToString();
            }
        }


        protected void drpCustomerName_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpCustomerCode.SelectedValue = drpCustomerName.SelectedValue;

            int id = Convert.ToInt32(drpCustomerCode.SelectedValue);
            BindCustDtls(id);

        }

        protected void rdbtnItemWise_CheckedChanged(object sender, EventArgs e)
        {
            radomItemCodeName();
        }

        protected void chkNewCustomer_CheckedChanged(object sender, EventArgs e)
        {
            IScheckCustomerDetail();
        }

        protected void drpCustomerCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpCustomerName.SelectedValue = drpCustomerCode.SelectedValue;

            int id = Convert.ToInt32(drpCustomerCode.SelectedValue);
            BindCustDtls(id);

        }

        private bool CheckDuplicateInGrid()
        {
            bool IsDuplicate = false;

            DtToCheck = (DataTable)ViewState["DataBind"];
            if(DtToCheck == null)
            { return false; }
            else
            {
                try
                {
                    if(DtToCheck.Rows.Count>0)
                    {
                        for(int i=0; i<DtToCheck.Rows.Count;i++)
                        {

                            //DtToCheck.Rows.Add();

                            int ItemCode = Convert.ToInt32(DtToCheck.Rows[i]["ID1"].ToString());
                            if (Convert.ToInt32(drpItemCode.SelectedValue) == ItemCode)
                            {
                                Response.Write("<script> alert('Duplicate values are not Allowed ...!!!') </Script>");
                                return true;
                            }
                            else
                            {

                            }
                        }
                    }
                    
                }
                catch(Exception ex)
                { }
             }

                return IsDuplicate;
        }
        //Bind All Data

        protected void btnAddQuotationDetails_Click(object sender, EventArgs e)
        {
            try {
                if(!CheckDuplicateInGrid())
                { 
                    BindAllData();
                    ResetBindData();
                }
                else
                { }
            }
            catch(Exception ex)
            { }
        }

        public void ResetBindData()
        {
            drpItemCode.SelectedIndex = 0;
            drpItemName.SelectedItem.Text = "---Select---";
            drpToolCode.SelectedIndex = 0;
            drpToolName.SelectedItem.Text = "---Select---";
            drpUOM.SelectedItem.Text = "---Select---";
            txtDeliveryLeadTime.Text = (DateTime.Now.ToString("hh:mm tt"));
            txtPackingCost.Text = "0.00";
            txtDevelopmentToolCost.Text = "0.00";
            txtMouldCost.Text = "0.00";
            txtMouldCavity.Text = "0";
            txtOtherCost.Text ="0.00";
            txtOtherCostRemark.Text = string.Empty;
            txtMaterial.Text = string.Empty;
            
            DataTable dt = (DataTable)ViewState["DataQuant"];
            //int j = dt.Rows.Count;
            dt.Rows.Clear();
            grdQuantityRate.DataSource = dt;
            grdQuantityRate.DataBind();
        }
        private string QuantityRate;
        public void BindAllData()
        {
             
            DtToCheck = (DataTable)ViewState["DataBind"];
            DataTable dt1 = CreateTable(14);
            try
            {
                dt1.Rows.Add();
                if (dt1.Rows.Count > 0)
                {
                    if (Convert.ToInt32(drpItemCode.SelectedValue) == 0)
                    { 
                        drpItemCode.SelectedIndex = 0;
                    }
                    else { 
                        dt1.Rows[0]["ID1"] = drpItemCode.SelectedValue;
                    }
                    if (string.Equals(drpItemName.SelectedItem, "---Select---"))
                    { drpItemName.SelectedItem.Text = string.Empty; }
                    else { dt1.Rows[0]["ID2"] = drpItemName.SelectedItem; }
                    if (Convert.ToInt32(drpToolCode.SelectedValue) == 0)
                    { drpItemCode.SelectedIndex = 0; }
                    else { dt1.Rows[0]["ID3"] = drpToolCode.SelectedValue; }
                    if (string.Equals(drpToolName.SelectedItem, "---Select---"))
                    { drpToolName.SelectedItem.Text = string.Empty; }
                    else
                    {
                        dt1.Rows[0]["ID4"] = drpToolName.SelectedItem;
                    }

                    dt1.Rows[0]["ID5"] = txtDeliveryLeadTime.Text;
                    dt1.Rows[0]["ID6"] = txtPackingCost.Text;
                    dt1.Rows[0]["ID7"] = txtDevelopmentToolCost.Text;
                    dt1.Rows[0]["ID8"] = txtMouldCost.Text;
                    dt1.Rows[0]["ID9"] = txtMouldCavity.Text;
                    dt1.Rows[0]["ID10"] = txtOtherCost.Text;
                    dt1.Rows[0]["ID11"] = txtOtherCostRemark.Text;
                    dt1.Rows[0]["ID12"] = txtMaterial.Text;
                    if (string.Equals(drpUOM.SelectedItem, "---Select---"))
                    { drpUOM.SelectedItem.Text = string.Empty; }
                    else { dt1.Rows[0]["ID13"] = drpUOM.SelectedItem; }

                    if(rdbtnItemWise.Checked)
                    { }
            
                    DataTable dt = (DataTable)ViewState["DataQuant"];
                    int j = dt.Rows.Count;
                    for(int i=0;i<j;i++)
                    {
                        QuantityRate += dt.Rows[i]["ID1"].ToString()+",";  
                        //QuantityRate += dt.Rows[i]["ID1"].ToString()+",";
                    }
               
                    dt1.Rows[0]["ID14"] = QuantityRate;
            
                    if (ViewState["DataBind"] == null)
                    {
                        BindAllList(dt1);
                    }
                    else
                    {
                       
                        dt1.Merge(DtToCheck);
                        BindAllList(dt1);
                    }
                }
            }
            catch(Exception ex)
            {
                dt1.Merge(DtToCheck);
                BindAllList(dt1);
            }
            
        }

        protected void BindAllList(DataTable dt)
        {
            ViewState["DataBind"] = dt;
            grdSupplierPO.DataSource = dt;
            grdSupplierPO.DataBind();
            if (grdSupplierPO.Rows.Count == 0)
            {
                ViewState["DataBind"] = null;
                dt.Rows.Clear();
            }
        }

        DataTable table = new DataTable();
        public void BindQuotation(DataRow dr)
        {
            drpItemCode.SelectedValue = dr["ID1"].ToString();
            drpItemName.SelectedValue = dr["ID1"].ToString();
            drpToolCode.SelectedValue = (dr["ID3"]).ToString();
            drpToolName.SelectedValue = (dr["ID3"]).ToString();
            txtDeliveryLeadTime.Text = (DateTime.Now.ToString("hh:mm tt"));
            txtPackingCost.Text = dr["ID6"].ToString();
            txtDevelopmentToolCost.Text = dr["ID7"].ToString();
            txtMouldCost.Text = dr["ID8"].ToString();
            txtMouldCavity.Text = dr["ID9"].ToString();
            txtOtherCost.Text = dr["ID10"].ToString();
            txtOtherCostRemark.Text = dr["ID11"].ToString();
            txtMaterial.Text = dr["ID12"].ToString();
            drpUOM.SelectedItem.Text = dr["ID13"].ToString();

            DataTable dt = (DataTable)ViewState["DataQuant"];
            int count=0;
            
                string val = dr["ID14"].ToString();
                char[] ch = val.ToCharArray();
                int j = ch.Length;

                for(int i=0;i<j;i++)
                {
                    if (ch[i]==',')
                    { 
                        count++;
                    }
                }
                DataTable dt1 = CreateTable(count);

                string[] arr = new string[count - 1];
                arr= dr["ID14"].ToString().Split(',');


                for(int i=0;i<=count-1;i++)
                {
                    dt1.Rows.Add();
                    dt1.Rows[i]["ID1"] = arr[i];
            
                }
                if(ViewState["DataQuant"]==null)
                { 
                    BindList(dt1);
                }
                else
                {
                    dt1.Merge(dt);
                    BindList(dt1);
                }
                
            
        }

        
        public void RemoveQuotation(DataRow dr)
        {
            try { 
            int ItemCode = Convert.ToInt32(dr["ID1"].ToString());
            
            QuotationId = Convert.ToInt32(drpQuotationNo.SelectedValue);

            int i=bal.DeleteQuotationData(QuotationId,ItemCode);
                if(i>0)
                { Lbl1.Text = "Record Deleted Successfully"; }
                else
                { Lbl1.Text = "Record Deleted Successfully"; }
            }
            catch(Exception ex)
            { }
        }
        protected void chkWithEnquiry_CheckedChanged(object sender, EventArgs e)
        {
            IsCheckEnquiryDetail();
        }

        protected void BindItemDetails(int id)
        {

            DataTable dt2 = new DataTable();
            dt2 = bal.BindItemDtls(id);
            drpUOM.Enabled = true;
            txtMaterial.Enabled = true;
            if (dt2.Rows.Count > 0)
            {
                drpUOM.SelectedValue = dt2.Rows[0]["UnitId"].ToString();

                txtMaterial.Text = dt2.Rows[0]["Material"].ToString();

            }
            
        }
        protected void BindQuotationNumber()
        {
            DataTable dt = new DataTable();
            dt = bal.BindQuotationNumber();
            drpQuotationNo.Items.Clear();
            drpQuotationNo.DataSource = dt;
            drpQuotationNo.DataTextField = "QuotationNumber";
            drpQuotationNo.DataValueField = "QuotationId";
            drpQuotationNo.DataBind();
            drpQuotationNo.Items.Insert(0, "---Select---");
            drpQuotationNo.SelectedIndex = 0;

        }
        protected void drpItemName_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpItemCode.SelectedValue = drpItemName.SelectedValue;
            if (Convert.ToInt32(drpItemCode.SelectedValue) != 0)
            {
                int id = Convert.ToInt32(drpItemCode.SelectedValue);

                BindItemDetails(id);
            
            }
        }

        protected void drpItemCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpItemName.SelectedValue = drpItemCode.SelectedValue;
            if (Convert.ToInt32(drpItemCode.SelectedValue) != 0)
            {
                int id = Convert.ToInt32(drpItemName.SelectedValue);
                BindItemDetails(id);
                //  BindGridView(id);
            }
        }

        protected void BindToolDetails(int id)
        {
            DataTable dt = new DataTable();
            dt = bal.BindToolDetails(id);
            drpToolName.Enabled = true;
            drpToolCode.Enabled = true;
            txtDeliveryLeadTime.Enabled = true;
            txtDevelopmentToolCost.Enabled = true;
            txtPackingCost.Enabled = true;
            txtMouldCost.Enabled = true;
            txtOtherCost.Enabled = true;
            txtOtherCostRemark.Enabled = true;
            if (dt.Rows.Count > 0)
            {
                drpToolName.SelectedItem.Text = dt.Rows[0]["ToolMouldname"].ToString();
                drpToolCode.SelectedItem.Text = dt.Rows[0]["ToolMouldCode"].ToString();
                txtDeliveryLeadTime.Text = DateTime.Now.ToString("hh:mm tt");
                    //(dt.Rows[0]["DeliveryLeadTime"]).ToString("hh:mm tt");
                txtDevelopmentToolCost.Text = (dt.Rows[0]["DevelopmentToolCost"].ToString());
                txtPackingCost.Text = dt.Rows[0]["PackingCost"].ToString();
                txtMouldCost.Text = dt.Rows[0]["MouldCost"].ToString();
                txtMouldCavity.Text = dt.Rows[0]["MouldCavity"].ToString();
              //  txtOtherCost.Text = dt.Rows[0]["OtherCost"].ToString();
                //txtOtherCostRemark.Text = dt.Rows[0]["OtherCostRemark"].ToString();
            }
        }
        protected void drpToolName_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpToolCode.SelectedValue = drpToolName.SelectedValue;
            string ToolName = drpToolName.SelectedItem.Text;
        if (string.Equals(drpToolName.SelectedItem.Text, "---Select---")||(string.Equals(drpToolName.SelectedItem.Text,ToolName)))
            {
                int Id = Convert.ToInt32(drpToolCode.SelectedValue);
                BindToolDetails(Id);
           }
        }

        protected void drpToolCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpToolName.SelectedValue = drpToolCode.SelectedValue;
            string ToolCode = drpToolCode.SelectedItem.Text;
            if (string.Equals(drpToolCode.SelectedItem.Text, "---Select---") || (string.Equals(drpToolCode.SelectedItem.Text, ToolCode)))
            {
                int id = Convert.ToInt32(drpToolName.SelectedValue);
                BindToolDetails(id);
            }

        }

        protected void drpPreparedByEmpCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpPreparedByEmpName.SelectedValue = drpPreparedByEmpCode.SelectedValue;
        }

        protected void drpPreparedByEmpName_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpPreparedByEmpCode.SelectedValue = drpPreparedByEmpName.SelectedValue;
        }

        protected void drpApprovedByEmpCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpApprovedByEmpName.SelectedValue = drpApprovedByEmpCode.SelectedValue;
        }

        protected void drpApprovedByEmpName_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpApprovedByEmpCode.SelectedValue = drpApprovedByEmpName.SelectedValue;
        }

        protected void drpReviewedByEmpCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpReviewedByEmpName.SelectedValue = drpReviewedByEmpCode.SelectedValue;
        }

        protected void drpReviewedByEmpName_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpReviewedByEmpCode.SelectedValue = drpReviewedByEmpName.SelectedValue;
        }

        protected void grdQuantityRate_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DataTable dt = new DataTable();
            if (e.CommandName == "Remove")
            {
                LinkButton TempLabel = new LinkButton();
                int index = Convert.ToInt32(e.CommandArgument);
                dt = (DataTable)ViewState["DataQuant"];
                dt.Rows.RemoveAt(index);
                BindList(dt);
            }

            if (e.CommandName == "RowEditing")
            {
                LinkButton TempLabel = new LinkButton();
                int index = Convert.ToInt32(e.CommandArgument);
                dt = (DataTable)ViewState["DataQuant"];
                BindQuantityData(dt.Rows[index]);
                dt.Rows.RemoveAt(index);
                BindList(dt);
            }


        }
        public void BindQuantityData(DataRow dr)
        {
            string[] arr = dr["ID1"].ToString().Split('/');
            txtQuantity.Text = arr[0];
            txtRate.Text = arr[1];
            drpRate.SelectedItem.Text = arr[2];
        }

        public DataTable CreateTable(int NoOfColumns)
        {
            DataTable dt = new DataTable();
            for (int i = 1; i <= NoOfColumns; i++)
            {
                string ID = "ID" + i;
                dt.Columns.Add(ID);
            }
            return dt;
        }

        protected void BindList(DataTable dt)
        {
            ViewState["DataQuant"] = dt;
            grdQuantityRate.DataSource = dt;
            grdQuantityRate.DataBind();
            if (grdQuantityRate.Rows.Count == 0)
                ViewState["DataQuant"] = null;
        }
        public void BindQuantData()
        {
            try
            {
                DataTable dt = (DataTable)ViewState["DataQuant"];
                
                DataTable dt1 = CreateTable(3);
                dt1.Rows.Add();

                dt1.Rows[0]["ID1"] = txtQuantity.Text + "/";
                dt1.Rows[0]["ID1"] += txtRate.Text+ "/";
                dt1.Rows[0]["ID1"] += drpRate.SelectedItem.Text;

                if (ViewState["DataQuant"] == null)
                {
                    BindList(dt1);
                }
                else
                {
                    
                        dt1.Merge(dt);
                        BindList(dt1);
                    
                }
            }catch(Exception ex)
            { }
        }


        
        protected void grdSupplierPO_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DataTable dt = new DataTable();
            if (e.CommandName == "Remove")
            {
                LinkButton TempLabel = new LinkButton();
                int index = Convert.ToInt32(e.CommandArgument);
                dt = (DataTable)ViewState["DataBind"];
                RemoveQuotation(dt.Rows[index]);
                dt.Rows.RemoveAt(index);
                BindAllList(dt);
            }

            if (e.CommandName == "RowEditing")
            {
                LinkButton TempLabel = new LinkButton();
                int index = Convert.ToInt32(e.CommandArgument);
                dt = (DataTable)ViewState["DataBind"];
                BindQuotation(dt.Rows[index]);
                dt.Rows.RemoveAt(index);
                BindAllList(dt);                
            }
        }

        public void BindEnquiryDetails(int id)
        {
            DataTable dt = new DataTable();
            dt = bal.BindEnquiryDetails(id);
            drpWithEnquiry.Enabled = true;
            txtRevisionNo.Enabled = true;
            txtQuotationNumber.Enabled = true;
            txtQuotationDate.Enabled = true;
            if (dt.Rows.Count > 0)
            {
                drpWithEnquiry.SelectedItem.Text = dt.Rows[0]["EnquiryNumber"].ToString();
                txtRevisionNo.Text = (dt.Rows[0]["EnqRefNumber"]).ToString();
                //txtQuotationNumber.Text = (dt.Rows[0]["QuotationNumber"]).ToString();
                txtQuotationDate.Text = (dt.Rows[0]["QuotationDate"]).ToString();
            }
        }
        protected void drpWithEnquiry_SelectedIndexChanged(object sender, EventArgs e)
        {
            int EnquiryId = Convert.ToInt32(drpWithEnquiry.SelectedValue);
            txtQuotationNumber.Enabled = false;
            BindEnquiryDetails(EnquiryId);


        }
        public void BindAllQuotationDetails(int QuotationId)
        {
            DataTable dt = new DataTable();
            dt = bal.BindAllQuotationDetails(QuotationId);
            drpWithEnquiry.Visible = false;
            if (dt.Rows.Count > 0)
            {
                //drpQuotationNo.SelectedIndex.Text = dt.Rows[0]["QuotationNumber"].ToString();
                bool WithEnquiry = Convert.ToBoolean(dt.Rows[0]["WithEnquiry"].ToString());
                if (WithEnquiry)
                {
                    chkWithEnquiry.Checked = true;
                    drpWithEnquiry.Visible = true;
                    drpWithEnquiry.SelectedValue = dt.Rows[0]["EnquiryId"].ToString();
                    txtRevisionNo.Text = (dt.Rows[0]["RevisionNumber"]).ToString();
                    txtQuotationNumber.Text = (dt.Rows[0]["QuotationNumber"]).ToString();
                    txtQuotationDate.Text = (dt.Rows[0]["QuotationDate"]).ToString();
                }
                else
                {
                    chkWithEnquiry.Checked = false;
                    txtRevisionNo.Text = (dt.Rows[0]["RevisionNumber"]).ToString();
                    txtQuotationNumber.Text = (dt.Rows[0]["QuotationNumber"]).ToString();
                    txtQuotationDate.Text = DateTime.Now.ToString("dd-MM-yyyy");
                    //(dt.Rows[0]["QuotationDate"]).ToString();
                }

                bool IsNewCustomer = Convert.ToBoolean(dt.Rows[0]["IsNewCustomer"].ToString());
                if (IsNewCustomer)
                {
                    chkNewCustomer.Checked = true;
                    txtCustomerName.Visible = true;
                    txtCustomerCode.Visible = true;
                    drpCustomerCode.Visible = false;
                    drpCustomerName.Visible = false;
                    txtCustomerName.Text = dt.Rows[0]["NewCustomerName"].ToString();
                    txtCustomerCode.Text = dt.Rows[0]["NewCustomerCode"].ToString();
                    txtAddress.Text = dt.Rows[0]["Address"].ToString();
                    txtContactPerson.Text = dt.Rows[0]["ContactPerson"].ToString();

                }
                else
                {
                    chkNewCustomer.Checked = false;
                    txtCustomerName.Visible = false;
                    txtCustomerCode.Visible = false;
                    drpCustomerName.SelectedValue = (dt.Rows[0]["Id"]).ToString();
                    drpCustomerCode.SelectedValue = (dt.Rows[0]["Id"]).ToString();
                    txtAddress.Text = dt.Rows[0]["Address"].ToString();
                    txtContactPerson.Text = dt.Rows[0]["ContactPerson"].ToString();
                }

                //       drpItemName.SelectedValue = (dt.Rows[0]["ID"]).ToString();
                //     drpItemCode.SelectedValue = (dt.Rows[0]["ID"]).ToString();

                //BindGridView(Convert.ToInt32(drpItemCode.SelectedValue));
                /* txtMaterial.Text= dt.Rows[0]["Material"].ToString();
                 drpUOM.SelectedValue= (dt.Rows[0]["UnitId"]).ToString();
                 drpToolName.SelectedValue= (dt.Rows[0]["ToolMouldId"]).ToString();
                 drpToolCode.SelectedValue = (dt.Rows[0]["ToolMouldId"]).ToString();
                 txtDeliveryLeadTime.Text = Convert.ToDateTime(dt.Rows[0]["DeliveryLeadTime"]).ToString();
                 txtPackingCost.Text= (dt.Rows[0]["PackingCost"]).ToString();
                 txtDevelopmentToolCost.Text= (dt.Rows[0]["DevelopmentToolCost"]).ToString();
                 txtMouldCost.Text= (dt.Rows[0]["MouldCost"]).ToString();
                 txtMouldCavity.Text= (dt.Rows[0]["MouldCavity"]).ToString();
                 txtOtherCost.Text= (dt.Rows[0]["OtherCost"]).ToString();
                 txtOtherCostRemark.Text= (dt.Rows[0]["OtherCostRemark"]).ToString();*/
                //   txtMaterial.Text = dt.Rows[0]["Material"].ToString();
                // drpUOM.SelectedValue = (dt.Rows[0]["UnitId"]).ToString();
     //           string qr= (dt.Rows[0]["QR"]).ToString();
       //         txtQuantity.Text = qr;
                //txtRate.Text = (dt.Rows[0]["Rate"]).ToString();
                //drpRate.SelectedValue = (dt.Rows[0]["SymbolId"]).ToString();
                txtEcess.Text = (dt.Rows[0]["Ecess"]).ToString();
                txtExcise.Text = (dt.Rows[0]["Excise"]).ToString();
                txtServiceTax.Text = (dt.Rows[0]["ServiceTax"]).ToString();
                txtExcise.Text = dt.Rows[0]["Excise"].ToString();
                txtSaleTax.Text = (dt.Rows[0]["SaleTax"]).ToString();
                drpPayment.SelectedValue = (dt.Rows[0]["PaymentTypeId"]).ToString();
                drpModeOfDispatch.SelectedValue = (dt.Rows[0]["TransportId"]).ToString();
                drpFrieght.SelectedValue = (dt.Rows[0]["FreightId"]).ToString();
                drpValidity.SelectedValue = (dt.Rows[0]["PlanTypeId"]).ToString();
                drpPacking.SelectedValue = (dt.Rows[0]["PackingId"]).ToString();
                drpStatus.SelectedValue = (dt.Rows[0]["StatusId"]).ToString();
                txtAgainstFormNo.Text = (dt.Rows[0]["AgainstForm"]).ToString();
                txtRemark.Text = (dt.Rows[0]["Remark"]).ToString();
                drpDrawing.SelectedValue = (dt.Rows[0]["DrawingId"]).ToString();
                txtSampleRequired.Text = (dt.Rows[0]["SampleRequired"]).ToString();
                drpDeliveryTerm.Text = (dt.Rows[0]["DeliveryTermId"]).ToString();
                txtDocumentRequired.Text = (dt.Rows[0]["DocumentRequired"]).ToString();
                txtAdvance.Text = (dt.Rows[0]["Advance"]).ToString();
                drpPreparedByEmpName.SelectedValue = (dt.Rows[0]["PreparedByEmpNameId"]).ToString();
                drpPreparedByEmpCode.SelectedValue = (dt.Rows[0]["PreparedByEmpNameId"]).ToString();
                drpApprovedByEmpName.SelectedValue = (dt.Rows[0]["ApprovedByEmpNameId"]).ToString();
                drpApprovedByEmpCode.SelectedValue = (dt.Rows[0]["ApprovedByEmpNameId"]).ToString();
                drpReviewedByEmpName.SelectedValue = (dt.Rows[0]["ReviewedByEmpNameId"]).ToString();
                drpReviewedByEmpCode.SelectedValue = (dt.Rows[0]["ReviewedByEmpNameId"]).ToString();
                txtItemSubject.Text = (dt.Rows[0]["ItemSubject"]).ToString();
                txtItemTerms.Text = (dt.Rows[0]["ItemTerms"]).ToString();
                txtToolSubject.Text = (dt.Rows[0]["ToolSubject"]).ToString();
                txtToolTerms.Text = (dt.Rows[0]["ToolTerms"]).ToString();

            }
        }
        public void BindQuantGrid(int QuotationId)
        {
            DataTable dt = new DataTable();
            dt = bal.BindQuantGrid(QuotationId);
        
            if(dt.Rows.Count>0)
            {
                DataTable dt1 = CreateTable(2);
                            
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt1.Rows.Add();

                    dt1.Rows[i]["ID1"] = dt.Rows[i]["QR"].ToString();
                    dt1.Rows[i]["ID2"] = dt.Rows[i]["SymbolCharacter"].ToString();

                }
                ViewState["DataQuant"] = dt1;
                grdQuantityRate.DataSource = dt1;
                grdQuantityRate.DataBind();
            }
            
        }
        public int QuotationId;
        protected void drpQuotationNo_SelectedIndexChanged(object sender, EventArgs e)
        { 
            btnSave.Enabled = false;
            btnUpdate.Enabled = true;
            //btnDelete.Enabled = true;
            QuotationId = Convert.ToInt32(drpQuotationNo.SelectedValue);
            BindAllQuotationDetails(QuotationId);
            BindGridView(QuotationId);
            //BindQuantGrid(QuotationId);
        }
        public void BindGridView(int QuotationId)
        {
            DataTable dt = bal.BindAllDataToGrid(QuotationId);

            
            if (dt.Rows.Count > 0)
            {
                DataTable dt1 = CreateTable(15);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt1.Rows.Add();
            
                    dt1.Rows[i]["ID1"] = dt.Rows[i]["ID"].ToString();
                    dt1.Rows[i]["ID2"] = dt.Rows[i]["ItemName"].ToString();
                    dt1.Rows[i]["ID3"] = dt.Rows[i]["ToolMouldId"].ToString();
                    dt1.Rows[i]["ID4"] = dt.Rows[i]["ToolmouldName"].ToString();
                    dt1.Rows[i]["ID5"] = dt.Rows[i]["DeliveryLeadTime"].ToString();
                    dt1.Rows[i]["ID6"] = dt.Rows[i]["PackingCost"].ToString();
                    dt1.Rows[i]["ID7"] = dt.Rows[i]["DevelopmentToolCost"].ToString();
                    dt1.Rows[i]["ID8"] = dt.Rows[i]["MouldCost"].ToString();
                    dt1.Rows[i]["ID9"] = dt.Rows[i]["MouldCavity"].ToString();
                    dt1.Rows[i]["ID10"] = dt.Rows[i]["OtherCost"].ToString();
                    dt1.Rows[i]["ID11"] = dt.Rows[i]["OtherCostRemark"].ToString();
                    dt1.Rows[i]["ID12"] = dt.Rows[i]["Material"].ToString();
                    dt1.Rows[i]["ID13"] = dt.Rows[i]["UnitName"].ToString();
                    dt1.Rows[i]["ID14"] = dt.Rows[i]["QR"].ToString();
            

                }

                
                ViewState["DataBind"] = dt1;

                if (dt1.Rows.Count > 0)
                {
                    grdSupplierPO.DataSource = dt1;
                    grdSupplierPO.DataBind();
                }
            }
            
        }

     

        
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (grdSupplierPO.Rows.Count > 0)
            {
                try
                {
                    int res = 0;
                    int i = BindGridDataDuringUpdate();
                    if (i > 0)
                    {
                        Label1.Text = "Please Fill Quotation Table ...!!!";
                        Response.Write("<script> alert('Please Fill Quotation Table ...!!!') </Script>");
                    }
                    else
                    {
                        QuotationId = Convert.ToInt32(drpQuotationNo.SelectedValue);
                        UpdateQuotationData(QuotationId);
                        res = bal.UpdateQuotationData1(model, dmodel);
                    }

                    //res = bal.UpdataQuotationData(model, dmodel, QuotationId);
                    rqCustomerCode.Enabled = false;
                    rqCustomerName.Enabled = false;

                    if (res > 0)
                    {
                        Lbl1.Text = "Record Updated Successfully";
                    }
                    else
                    {
                        Lbl1.Text = "Record not Updated Successfully";
                        Label1.Visible = false;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            else
            {
                Response.Write("<script> alert('Add button not hit') </Script>");
            }

        }

        //protected void btnDelete_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        int res = 0;
        //        QuotationId = Convert.ToInt32(drpQuotationNo.SelectedValue);
        //         //res= bal.DeleteQuotationData(QuotationId);
        //        if (res > 0)
        //        {
        //            Lbl1.Text = "Record Deleted Successfully";
        //        }
        //        else
        //        {
        //            Lbl1.Text = "Record not Deleted Successfully";
        //        }
        //    }
        //    catch(Exception ex)
        //    {
        //        Console.WriteLine(ex);
        //    }
        //}

        protected void btnNew_Click(object sender, EventArgs e)
        {
            ResetAllData();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("QuotationMaster.aspx");
        }

        
        public int BindGridDataDuringSave()
        {
            int i;
            string ID = "";
            DtToCheck = (DataTable)ViewState["DataBind"];

            try
            {
                // int k = DtToCheck.Rows.Count;
                if (DtToCheck.Rows.Count > 0)
                {
                    ID = DtToCheck.Rows[0]["ID1"].ToString();

                    if (string.Equals(ID, ""))
                    {
                        DataTable dt1 = CreateTable(15);
                        dt1.Rows.Clear();
                        ViewState["DataBind"] = null;
                        BindAllList(dt1);
                        i = 1;
                    }
                    else
                    {
                        i = 0;
                    }

                }
                else
                {
                    i = 1;
                }
            }catch(Exception ex)
            {
                Console.WriteLine(ex);
                i = 1;
            }
            return i;
        }
        public int BindGridDataDuringUpdate()
        {
            int i;
            DtToCheck = (DataTable)ViewState["DataBind"];

            if (DtToCheck==null)
            {
               DataTable dt1 = CreateTable(15);
               dt1.Rows.Clear();
               ViewState["DataBind"] = null;
               BindAllList(dt1);
               i = 1;

            }
            else
            {
                i = 0;
            }
            return i;
        }

    }
}