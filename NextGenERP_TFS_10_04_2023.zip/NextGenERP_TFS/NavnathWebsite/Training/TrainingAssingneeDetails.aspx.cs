﻿using BAL;
using Microsoft.ReportingServices.ReportProcessing.OnDemandReportObjectModel;
using Modal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NavnathWebsite.Training
{
    public partial class TrainingDetailsAssignee : System.Web.UI.Page
    {
        TrainingAssigneeDetailsBal bal = new TrainingAssigneeDetailsBal();
        TrainingAssigneeDetailsModel model = new TrainingAssigneeDetailsModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                BindDropTraingSubject();
                BindDrpEmpCode();
                BindDrpEmpName();
            }
        }

        private void BindDrpEmpCode()
        {
            try
            {
                DataTable dt = bal.BindEmpMasters();
                drpEmpCode.DataSource = dt;
                drpEmpCode.DataTextField = "EmpCode";
                drpEmpCode.DataValueField = "EmpCode";
                drpEmpCode.DataBind();
                drpEmpCode.Items.Insert(0, "---Select---");
                drpEmpCode.SelectedIndex = 0;
            }
            catch (Exception ex)
            { Console.WriteLine(ex); }

        }
        private void BindDrpEmpName()
        {
            try
            {
                DataTable dt = bal.BindEmpMasters();
                drpEmpName.DataSource = dt;
                drpEmpName.DataTextField = "EmpName";
                drpEmpName.DataValueField = "EmpCode";
                drpEmpName.DataBind();
                drpEmpName.Items.Insert(0, "---Select---");
                drpEmpName.SelectedIndex = 0;
            }
            catch (Exception ex)
            { Console.WriteLine(ex); }

        }
        private void BindDropTraingSubject()
        {
            try
            { 
            DataTable dt = bal.GetTraingSubject();
            drpTrainingSubject.DataSource = dt;
            drpTrainingSubject.DataTextField = "TrainningSubject";
            drpTrainingSubject.DataValueField = "TrainingSubjectId";
            drpTrainingSubject.DataBind();
            drpTrainingSubject.Items.Insert(0, "---Select---");
            drpTrainingSubject.SelectedIndex = 0;
            }
            catch(Exception ex)
            { Console.WriteLine(ex); }
        }

        private void BindDropTrainingTopic(int TrainingSubjectId)
        {
            try
            {
                model.TrainingSubId = TrainingSubjectId;
                DataTable dt = bal.GetTrainingTopic(model);
                drpTrainingTopic.Items.Clear();
                drpTrainingTopic.DataSource = dt;
                drpTrainingTopic.DataTextField = "TrainingRequiredOn";
                drpTrainingTopic.DataValueField = "TrainingMatrixId";
                drpTrainingTopic.DataBind();
                drpTrainingTopic.Items.Insert(0, "---Select---");
                drpTrainingTopic.SelectedIndex = 0;
            }
            catch (Exception ex)
            { Console.WriteLine(ex); }
        }

        private void BindDropTrainingId(int TrainingMatrixId)
        {
            try
            {
                model.TrainingMatrixId = TrainingMatrixId;
                DataTable dt = bal.GetTrainingId(model);
                drpTrainingId.Items.Clear();
                drpTrainingId.DataSource = dt;
                drpTrainingId.DataTextField = "TrainingId";
                drpTrainingId.DataValueField = "PlanningForTrainingId";
                drpTrainingId.DataBind();
                drpTrainingId.Items.Insert(0, "---Select---");
                drpTrainingId.SelectedIndex = 0;
            }
            catch (Exception ex)
            { Console.WriteLine(ex); }
        }
        protected void drpTrainingSubject_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDropTrainingTopic(Convert.ToInt32(drpTrainingSubject.SelectedValue));
        }

        protected void drpTrainingTopic_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDropTrainingId(Convert.ToInt32(drpTrainingTopic.SelectedValue));
        }

        protected void drpEmpCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpEmpName.SelectedValue = drpEmpCode.SelectedValue;
        }

        protected void drpEmpName_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpEmpCode.SelectedValue = drpEmpName.SelectedValue;
        }

        public DataTable CreateDataTable(int Noofcolumn)
        {
            DataTable DT = new DataTable();

            for (int i = 1; i <= Noofcolumn; i++)
            {
                DT.Columns.Add("ID" + i);
            }
            return DT;
        }
        public void Reset()
        {
            drpTrainingSubject.SelectedIndex = 0;
            drpTrainingTopic.SelectedIndex = 0;
            drpEmpCode.SelectedIndex = 0;
            drpEmpName.SelectedIndex = 0;
            drpTrainingId.SelectedIndex = 0;
        }
        protected void btnAddRate_Click(object sender, EventArgs e)
        {
            if (string.Equals(drpTrainingSubject.SelectedItem.Text, "---Select---")) { Response.Write("<script> alert ('Please Select Training Subject')</script>"); }
            else {
                model.TrainingID = drpTrainingId.SelectedItem.ToString();
                DataTable dt = bal.GetRecByTrainingId(model);
                DataTable oldDt = (DataTable)ViewState["DTCheck"];
                DataTable dt1 = CreateDataTable(11);

                //int i = 1;
                //if (oldDt != null)
                //{
                //    foreach(DataRow Dr in oldDt.Rows)
                //    {
                //        i =Convert.ToInt32(Dr["ID1"]);
                //        i++;
                //    }
                //}

                dt1.Rows.Add();
                //  dt1.Rows[0]["ID1"] = i;
                dt1.Rows[0]["ID1"] = drpTrainingId.SelectedItem;
                dt1.Rows[0]["ID2"] = drpTrainingSubject.SelectedItem;
                dt1.Rows[0]["ID3"] = drpTrainingTopic.SelectedItem;
                dt1.Rows[0]["ID4"] = dt.Rows[0]["PlanDate"];
                dt1.Rows[0]["ID5"] = drpEmpCode.SelectedItem;
                dt1.Rows[0]["ID6"] = drpEmpName.SelectedItem;
                dt1.Rows[0]["ID7"] = drpTrainingSubject.SelectedValue;
                dt1.Rows[0]["ID8"] = drpTrainingTopic.SelectedValue;
                dt1.Rows[0]["ID10"] = ViewState["TrainingDetailId"];
                //dt1.Rows[0]["ID7"] = DDLTrainingSub.SelectedValue;
                //dt1.Rows[0]["ID8"] = DDLTainingTopic.SelectedValue;
                Reset();
                if (oldDt != null)
                {
                    dt1.Merge(oldDt);
                }
                ViewState["DTCheck"] = dt1;
                grdTraingTable.DataSource = dt1;
                grdTraingTable.DataBind();
            }

        }

        protected void btnSaveItem_Click(object sender, EventArgs e)
        {

            DataTable oldDt = (DataTable)ViewState["DTCheck"];
            DataTable newdt = CreateDataTable(8);

            if(oldDt.Rows.Count>0)
            {
                newdt.Merge(oldDt);
            }

            int i = bal.SaveAssignedData(newdt);

            if (i > 0)
            {
                Response.Write("<script> alert ('Data Saved Successfully')</script>");
                Label1.Text = "Data Saved successfully !!!";
            }
            else
            {
                Response.Write("<script> alert ('Data Not Saved ')</script>");
                Label1.Text = "Data Not Saved Successfully !!!";
            }
        }

        protected void btnCancelItem_Click(object sender, EventArgs e)
        {
            Response.Redirect("TrainingAssingneeDetails.aspx");
        }

        protected void btnNewItem_Click(object sender, EventArgs e)
        {
            drpTrainingId.SelectedIndex = 0;
            drpTrainingSubject.SelectedIndex = 0;
            drpTrainingTopic.SelectedIndex = 0;
            drpEmpCode.SelectedIndex = 0;
            drpEmpName.SelectedIndex = 0;
            DataTable oldDt = new DataTable();
            oldDt = null;
            ViewState["DTCheck"] = oldDt;
            grdTraingTable.DataSource = oldDt;
            grdTraingTable.DataBind();

        }

        protected void grdTraingTable_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DataTable dt = new DataTable();
            if (e.CommandName == "RowEditing")
            {
                LinkButton TempLabel = new LinkButton();
                int index = Convert.ToInt32(e.CommandArgument);
                dt = (DataTable)ViewState["DTCheck"];
                BindTrainingDetails(dt.Rows[index]);
                dt.Rows.RemoveAt(index);
                BindList(dt);
            }
            if (e.CommandName == "Remove")
            {
                LinkButton TempLabel = new LinkButton();
                int index = Convert.ToInt32(e.CommandArgument);
                dt = (DataTable)ViewState["DTCheck"];
                dt.Rows.RemoveAt(index);
                BindList(dt);
            }
        }
        
        private void BindTrainingDetails(DataRow row)
        {
            drpTrainingId.SelectedItem.Text = row["ID1"].ToString();
            drpTrainingSubject.SelectedValue= row["ID8"].ToString();
            drpTrainingTopic.SelectedValue= row["ID9"].ToString();
            drpEmpCode.SelectedValue= row["ID5"].ToString();
            drpEmpName.SelectedValue= row["ID5"].ToString();
            ViewState["TrainingDetailId"] = Convert.ToInt32(row["ID10"]);
        //    model.TrainingDate =Convert.ToDateTime(row["ID4"]);
        }

        protected void BindList(DataTable dt)
        {
            ViewState["DTCheck"] = dt;
            grdTraingTable.DataSource = dt;
            grdTraingTable.DataBind();
            if (grdTraingTable.Rows.Count == 0)
                ViewState["DTCheck"] = null;
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {


            DataTable dt = new DataTable();
            dt = bal.SearchAssignedData(drpTrainingId.SelectedItem.ToString());

            DataTable dt1 = CreateDataTable(11);



            if (dt.Rows.Count > 0)
            {
                int i = 0;
                foreach (DataRow Dr in dt.Rows)
                {
                    dt1.Rows.Add();
                    dt1.Rows[i]["ID1"] = dt.Rows[i]["TrainingID"];
                    dt1.Rows[i]["ID2"] = dt.Rows[i]["TrainningSubject"];
                    dt1.Rows[i]["ID3"] = dt.Rows[i]["TrainingRequiredOn"];
                    dt1.Rows[i]["ID4"] = dt.Rows[i]["TrainingDate"];
                    dt1.Rows[i]["ID5"] = dt.Rows[i]["EmpCode"];
                    dt1.Rows[i]["ID6"] = dt.Rows[i]["EmpName"];
                    dt1.Rows[i]["ID7"] = dt.Rows[i]["PlanningForTrainingId"];
                    dt1.Rows[i]["ID8"] = dt.Rows[i]["TrainingSubjectId"];
                    dt1.Rows[i]["ID9"] = dt.Rows[i]["TrainingMatrixId"];
                    dt1.Rows[i]["ID10"] = dt.Rows[i]["TrainingEmployeeAssignDtl"];

                    i++;

                }

                ViewState["DTCheck"] = dt1;
                grdTraingTable.DataSource = dt1;
                grdTraingTable.DataBind();

            }
            else
            {
                Response.Write("<script> alert('Record Not Available..')</script>");
            }


        }

        protected void btnUpdateItem_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)ViewState["DTCheck"];

            //  DataTable dt1 = CreateDataTable(11);
            //  dt1.Rows.Add();
            //  dt1.Rows[0]["ID1"] = drpTrainingId.SelectedItem;
            //  dt1.Rows[0]["ID2"] = drpTrainingSubject.SelectedItem;
            //  dt1.Rows[0]["ID3"] = drpTrainingTopic.SelectedItem;
            ////  dt1.Rows[0]["ID4"] = TrainingDate;
            //  dt1.Rows[0]["ID5"] = drpEmpCode.SelectedItem;
            //  dt1.Rows[0]["ID6"] = drpEmpName.SelectedItem;
            //  dt1.Rows[0]["ID7"] = drpTrainingSubject.SelectedValue;
            //  dt1.Rows[0]["ID8"] = drpTrainingTopic.SelectedValue;
            //  dt1.Rows[0]["ID10"] = ViewState["TrainingDetailId"];
            //int trainingDetailId= Convert.ToInt32(ViewState["TrainingDetailId"]); 
            int i = 0;
            if (dt.Rows.Count>0)
            {
                //dt.Merge(dt1);
                 i= bal.UpdateAssignDtl(dt);
            }
            //else
            //{
            //    dt.Merge(dt1);
            //}
            

            //int i = bal.UpdateAssignDtl(dt);

            if (i > 0)
            {
                Response.Write("<script> alert ('Data Updated Successfully')</script>");
                Label1.Text = "Data Updated successfully !!!";
            }
            else
            {
                Response.Write("<script> alert ('Data Not Updated ')</script>");
                Label1.Text = "Data Not Updated Successfully !!!";
            }
        }
    }
}





        